# X-road Gateway API
[![Quality Gate Status](https://sonarqube.riaint.ee/api/project_badges/measure?project=SUN.event-service-xroad-gateway&metric=alert_status&token=dd0647a95c1a367f84d6c62c1bd70762aa01d4e4)](https://sonarqube.riaint.ee/dashboard?id=SUN.event-service-xroad-gateway)

## Features
* Spring Boot 3.0.0
* Java 17
* Lombok
* Swagger

## How to run:
* Start RabbitMQ (run docker-compose up command in folder /tools/docker-compose/RabbitMq of helm-charts project)
* Run via gradle command or directly from intellij;

### URLs
Swagger: http://localhost:8105/event-service-xroad-gateway/swagger-ui.html
