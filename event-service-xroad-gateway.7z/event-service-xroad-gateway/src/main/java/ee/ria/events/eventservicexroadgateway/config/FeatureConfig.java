package ee.ria.events.eventservicexroadgateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration()
public class FeatureConfig {

  @Value("${app.features.ALLOW_RABBIT_MQ.enabled:true}")
  private Boolean isRabbitMqEnabled;

  @Bean
  public Boolean isRabbitMqEnabled() {
    return isRabbitMqEnabled;
  }

}
