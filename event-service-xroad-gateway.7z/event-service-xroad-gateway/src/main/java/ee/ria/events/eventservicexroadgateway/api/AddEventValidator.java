package ee.ria.events.eventservicexroadgateway.api;

import ee.ria.events.eventservicexroadgateway.openapigenerate.model.V1EventDto;
import ee.ria.events.eventservicexroadgateway.validation.AbstractValidator;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

@Component
public class AddEventValidator extends AbstractValidator<V1EventDto> {

  public AddEventValidator() {
    super(V1EventDto.class);
  }

  @Override
  protected void validateTarget(V1EventDto target, Errors errors) {
    if (!ObjectUtils.allNotNull(target.getProcessId(), target.getEventDateTime())) {
      reject(errors);
    }
    if (StringUtils.isAnyBlank(target.getEvent(), target.getPersonCode())) {
      reject(errors);
    }
  }

  private static void reject(Errors errors) {
    errors.reject("empty_fields", "Required fields: event, personCode, processId and eventDateTime");
  }
}
