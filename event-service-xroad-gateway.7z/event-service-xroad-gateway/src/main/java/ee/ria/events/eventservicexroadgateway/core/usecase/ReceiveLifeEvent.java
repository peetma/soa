package ee.ria.events.eventservicexroadgateway.core.usecase;

import ee.ria.events.eventservicexroadgateway.core.model.LifeEvent;
import ee.ria.events.eventservicexroadgateway.publisher.EventPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ReceiveLifeEvent {

  private final EventPublisher eventPublisher;

  public Mono<LifeEvent> execute(LifeEvent lifeEvent) {
    eventPublisher.sendMessage(lifeEvent);
    return Mono.just(lifeEvent);
  }

}
