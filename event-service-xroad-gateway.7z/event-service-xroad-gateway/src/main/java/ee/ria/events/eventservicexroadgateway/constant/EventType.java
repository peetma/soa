package ee.ria.events.eventservicexroadgateway.constant;

public class EventType {
    public static final String MARRIAGE="abiellumine";
    public static final String NAME_CHANGE="nimevahetus";
}
