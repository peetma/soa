package ee.ria.events.eventservicexroadgateway.validation;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
public abstract class AbstractValidator<T> implements Validator {

  final Class<T> typeParameterClass;

  @Override
  public boolean supports(Class<?> clazz) {
    return typeParameterClass.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    validateTarget((T) target, errors);
  }

  public Mono<T> validate(T target) {
    return Mono.just(target)
        .map(body -> {
          Errors errors = new BeanPropertyBindingResult(
              body,
              target.getClass().getName());
          validate(body, errors);

          if (errors.getAllErrors().isEmpty()) {
            return target;
          } else {
            throw new ValidationFailedException(errors);
          }
        });
  }

  protected abstract void validateTarget(T target, Errors errors);
}
