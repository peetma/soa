package ee.ria.events.eventservicexroadgateway.core.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Value;
import lombok.With;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.OffsetDateTime;
import java.util.UUID;

@Value
@Builder
@Getter
public class LifeEvent {

  String personCode;

  String personRole;

  UUID processId;

  UUID parentProcessId;

  String event;
  @With
  String eventService;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  OffsetDateTime eventDateTime;

}
