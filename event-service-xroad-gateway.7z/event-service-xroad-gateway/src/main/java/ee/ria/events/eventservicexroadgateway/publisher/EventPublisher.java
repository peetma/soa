package ee.ria.events.eventservicexroadgateway.publisher;

import com.fasterxml.jackson.databind.ObjectMapper;
import ee.ria.events.eventservicexroadgateway.core.model.LifeEvent;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class EventPublisher {
  private final RabbitTemplate rabbitTemplate;
  private final ObjectMapper objectMapper;
  private final Boolean isRabbitMqEnabled;

  @SneakyThrows
  public void sendMessage(LifeEvent lifeEvent) {
    log.info("Sending message {}", lifeEvent);
    if (isRabbitMqEnabled) {
      String jsonLifeEvent = objectMapper.writeValueAsString(lifeEvent);
      rabbitTemplate.convertAndSend("queueing.life-event.saved", jsonLifeEvent);
    }
  }
}
