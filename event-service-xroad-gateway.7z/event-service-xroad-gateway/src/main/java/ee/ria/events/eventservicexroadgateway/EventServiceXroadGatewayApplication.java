package ee.ria.events.eventservicexroadgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventServiceXroadGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventServiceXroadGatewayApplication.class, args);
    }

}
