package ee.ria.events.eventservicexroadgateway.api;

import ee.ria.events.eventservicexroadgateway.api.mapper.LifeEventMapper;
import ee.ria.events.eventservicexroadgateway.constant.EventType;
import ee.ria.events.eventservicexroadgateway.core.usecase.ReceiveLifeEvent;
import ee.ria.events.eventservicexroadgateway.openapigenerate.EventsApi;
import ee.ria.events.eventservicexroadgateway.openapigenerate.model.V1EventDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static org.springframework.http.HttpStatus.CREATED;

@RestController
@RequiredArgsConstructor
public class XRoadEventsController implements EventsApi {

    private final ReceiveLifeEvent receiveLifeEvent;
    private final LifeEventMapper mapper;
    private final AddEventValidator addEventValidator;

    @Override
    public Mono<ResponseEntity<Void>> addMarriageEvent(Mono<V1EventDto> v1EventDto,
                                                       final ServerWebExchange exchange) {
        return addEvent(EventType.MARRIAGE, v1EventDto);
    }

    @Override
    public Mono<ResponseEntity<Void>> addNameChangeEvent(Mono<V1EventDto> v1EventDto,
                                                         final ServerWebExchange exchange) {
        return addEvent(EventType.NAME_CHANGE, v1EventDto);
    }

    private Mono<ResponseEntity<Void>> addEvent(String eventType, Mono<V1EventDto> v1EventDto) {
        return v1EventDto
                .flatMap(addEventValidator::validate)
                .map(dto -> mapper.toModel(dto).withEventService(eventType))
                .flatMap(receiveLifeEvent::execute)
                .map(sentLifeEvent -> ResponseEntity.status(CREATED).build());
    }
}
