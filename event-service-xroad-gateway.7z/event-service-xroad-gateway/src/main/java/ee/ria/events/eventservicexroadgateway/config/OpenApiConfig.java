package ee.ria.events.eventservicexroadgateway.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class OpenApiConfig {

  @Bean
  public OpenAPI openAPI(
      @Value("${openapi.title:Define property 'openapi.title'!}") String title,
      @Value("${openapi.description:Define property 'openapi.description'!}") String description,
      @Value("${openapi.server:Define property 'openapi.server'!}") String serverUrl
  ) {
    var server = new Server();
    server.setUrl(serverUrl);
    return new OpenAPI()
        .addServersItem(server)
        .info(new Info()
            .title(title)
            .description(description)
        );
  }
}
