package ee.ria.events.eventservicexroadgateway.api.mapper;

import ee.ria.events.eventservicexroadgateway.core.model.LifeEvent;
import ee.ria.events.eventservicexroadgateway.openapigenerate.model.V1EventDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface LifeEventMapper extends BaseDtoMapper<V1EventDto, LifeEvent> {
}
