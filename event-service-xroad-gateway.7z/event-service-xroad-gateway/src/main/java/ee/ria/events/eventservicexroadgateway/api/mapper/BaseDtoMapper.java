package ee.ria.events.eventservicexroadgateway.api.mapper;

public interface BaseDtoMapper<E, M> {

  M toModel(E dto);

}
