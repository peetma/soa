package ee.ria.events.eventservicexroadgateway.it.fitnesse.fixtures.base;

import ee.ria.events.eventservicexroadgateway.it.fitnesse.FitnesseContextHolder;
import ee.ria.events.eventservicexroadgateway.it.fitnesse.UseCase;
import ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.UseCaseFactory;
import org.springframework.core.ResolvableType;

public abstract class UseCaseFixture<U extends UseCase<I, O>, I, O> {

  private final U useCase = createUseCase();

  protected abstract void setInput(I input);

  protected abstract void setOutput(O output);

  public UseCaseFixture() {
    I sharedInput = FitnesseContextHolder.shared(inputClass());
    setInput(sharedInput);
  }

  public void execute() {
    I inputCopy = FitnesseContextHolder.copy(inputClass());
    O output = useCase.execute(inputCopy);
    setOutput(output);
  }

  private U createUseCase() {
    return FitnesseContextHolder.bean(UseCaseFactory.class)
        .create(useCaseClass());
  }

  @SuppressWarnings("unchecked")
  private Class<U> useCaseClass() {
    return (Class<U>) resolveGeneric(0);
  }

  @SuppressWarnings("unchecked")
  private Class<I> inputClass() {
    return (Class<I>) resolveGeneric(1);
  }

  private Class<?> resolveGeneric(int... indexes) {
    return ResolvableType.forClass(UseCaseFixture.class, this.getClass())
        .resolveGeneric(indexes);
  }
}
