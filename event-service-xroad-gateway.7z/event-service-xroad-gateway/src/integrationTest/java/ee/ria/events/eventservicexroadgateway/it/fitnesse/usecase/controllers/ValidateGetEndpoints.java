package ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers;

import ee.ria.events.eventservicexroadgateway.it.fitnesse.UseCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

public interface ValidateGetEndpoints extends UseCase<ValidateGetEndpoints.Input, ValidateGetEndpoints.Output> {

  @Getter
  @Setter
  class Input {
    private String endpoint;

    private Integer expectedStatus;
    private String resultJson;
  }

  @Data
  @Builder
  @AllArgsConstructor
  class Output {
    private Boolean assertionPassed;
  }
}
