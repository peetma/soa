package ee.ria.events.eventservicexroadgateway.it.fitnesse.fixtures;

import ee.ria.events.eventservicexroadgateway.it.fitnesse.fixtures.base.UseCaseFixture;
import ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers.ValidatePostEndpoints;
import ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers.ValidatePostEndpoints.Input;
import ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers.ValidatePostEndpoints.Output;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Delegate;

import static lombok.AccessLevel.PROTECTED;

@Getter(PROTECTED)
@Setter(PROTECTED)
public class ValidatePostEndpointsFixture extends UseCaseFixture<ValidatePostEndpoints, Input, Output> {

  @Delegate
  private Input input;

  @Delegate
  private Output output;

}
