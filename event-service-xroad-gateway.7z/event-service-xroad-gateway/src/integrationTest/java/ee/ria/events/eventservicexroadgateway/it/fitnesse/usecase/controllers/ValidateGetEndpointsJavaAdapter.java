package ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.web.reactive.server.WebTestClient;

@Slf4j
@Component
@WebFluxTest
@RequiredArgsConstructor
public class ValidateGetEndpointsJavaAdapter implements ValidateGetEndpoints {

  @Autowired
  private WebTestClient webTestClient;

  @Override
  public Output execute(Input input) {
    try {
      WebTestClient.ResponseSpec responseSpec = webTestClient.get()
          .uri(input.getEndpoint())
          .accept(MediaType.APPLICATION_JSON)
          .exchange()
          .expectStatus().isEqualTo(input.getExpectedStatus());
      if (input.getResultJson() != null) {
        responseSpec.expectBody().json(input.getResultJson(), true);
      }
    } catch (AssertionError | Exception e) {
      log.error("Query failed", e);
      return new Output(false);
    }
    return new Output(true);
  }

}
