package ee.ria.events.eventservicexroadgateway.it.fitnesse.usecase.controllers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;

@Slf4j
@Component
@WebFluxTest
@RequiredArgsConstructor
public class ValidatePostEndpointsJavaAdapter implements ValidatePostEndpoints {

  @Autowired
  private WebTestClient webTestClient;

  @Override
  public Output execute(Input input) {
    try {
      WebTestClient.RequestBodySpec spec = webTestClient.post()
          .uri(input.getEndpoint())
          .contentType(MediaType.APPLICATION_JSON)
          .accept(MediaType.APPLICATION_JSON);
      if (input.getContentJson() != null) {
        spec.body(BodyInserters.fromValue(input.getContentJson()));
      }

      WebTestClient.ResponseSpec responseSpec = spec.exchange()
          .expectStatus().isEqualTo(input.getExpectedStatus());
      if (input.getResultJson() != null) {
        responseSpec.expectBody().json(input.getResultJson(), true);
      }
    } catch (Exception e) {
      log.error("Query failed", e);
      return new Output(false);
    }
    return new Output(true);
  }

}
