package ee.ria.events.eventservicexroadgateway.it.fitnesse.fixtures;

import ee.ria.events.eventservicexroadgateway.it.fitnesse.FitnesseContextHolder;
import org.springframework.core.env.Environment;

public class SpringContextCheck {
  private final Environment environment = FitnesseContextHolder.bean(Environment.class);

  public int activeProfileCount() {
    return environment.getActiveProfiles().length;
  }

  public String firstActiveProfile() {
    return environment.getActiveProfiles()[0];
  }
}
