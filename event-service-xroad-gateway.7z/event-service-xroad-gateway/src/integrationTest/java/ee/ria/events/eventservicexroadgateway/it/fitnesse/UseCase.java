package ee.ria.events.eventservicexroadgateway.it.fitnesse;

public interface UseCase<T, R> {

  R execute(T command);

}
