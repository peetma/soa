package ee.ria.events.eventservicexroadgateway.it.fitnesse.fixtures.common;

import ee.ria.events.eventservicexroadgateway.it.fitnesse.FitnesseContextHolder;

public class ContextFixture {

  public void clearContext() {
    FitnesseContextHolder.clear();
  }

  public String getUniqueSuffix() {
    return String.valueOf(System.currentTimeMillis());
  }
}
