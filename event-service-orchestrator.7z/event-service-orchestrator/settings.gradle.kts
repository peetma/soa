rootProject.name = "event-service-orchestrator"

pluginManagement {
  repositories {
    maven("https://nexus.riaint.ee/repository/plugins-gradle-org-proxy/")
  }
}

plugins {
  // See https://jmfayard.github.io/refreshVersions
  id("de.fayard.refreshVersions") version "0.51.0"
}
