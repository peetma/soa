package ee.ria.events.eventserviceorchestrator.publisher;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class LifeEventReceivedPublisherTest {

  private LifeEventReceivedPublisher publisher;

  @Mock
  private RabbitTemplate rabbitTemplate;

  private final String lifeEventSavedQueue = "test-life-event-queue";

  @BeforeEach
  public void setUp() {
    publisher = new LifeEventReceivedPublisher(rabbitTemplate, lifeEventSavedQueue);
  }

  @Test
  public void testSendMessage() {
    // Given
    var messageId = "test-message-id";
    var messageProperties = new MessageProperties();
    messageProperties.setMessageId(messageId);
    var message = new Message("test-message-body".getBytes(), messageProperties);
    var correlationData = new CorrelationData(messageId);

    // When
    publisher.sendMessage(message);

    // Then
    verify(rabbitTemplate).convertAndSend(eq(lifeEventSavedQueue), eq(message), any(CorrelationData.class));
  }

}

