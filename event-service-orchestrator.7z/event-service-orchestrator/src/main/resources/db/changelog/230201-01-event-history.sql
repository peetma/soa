--liquibase formatted sql

--changeset mihkel:230201-01-event_history creation
drop table if exists event_history;
create table event_history
(
    id          bigserial
        CONSTRAINT pk_event_history PRIMARY KEY,
    event       jsonb     NOT NULL,
    created     timestamp NOT NULL DEFAULT current_timestamp,
    created_by  text      NOT NULL DEFAULT 'SYSTEM',
    modified    timestamp NOT NULL DEFAULT current_timestamp,
    modified_by text      NOT NULL DEFAULT 'SYSTEM'
)
--rollback DROP TABLE public.event_history
