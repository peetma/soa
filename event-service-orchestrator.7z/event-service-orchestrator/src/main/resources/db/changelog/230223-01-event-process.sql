--liquibase formatted sql

--changeset sarah:230223-01-event_process_creation
create table event_process
(
    id          bigserial
        CONSTRAINT pk_event_process PRIMARY KEY,
    process_id        uuid      NOT NULL,
    parent_process_id uuid      NULL,
    person_code       text      NOT NULL,
    process_setup     jsonb     NOT NULL,
    steps             jsonb     NOT NULL,
    created           timestamp NOT NULL DEFAULT current_timestamp,
    created_by        text      NOT NULL DEFAULT 'SYSTEM',
    modified          timestamp NOT NULL DEFAULT current_timestamp,
    modified_by       text      NOT NULL DEFAULT 'SYSTEM'
)
--rollback DROP TABLE public.event_process
