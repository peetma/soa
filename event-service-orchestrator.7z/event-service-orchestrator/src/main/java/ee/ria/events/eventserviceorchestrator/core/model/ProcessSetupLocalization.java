package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class ProcessSetupLocalization {
  Integer id;
  Integer serviceSetupVersionId;
  String language;
  GeneralConfig general;
  List<StepConfig> steps;
}
