package ee.ria.events.eventserviceorchestrator.persistence.repository;

import ee.ria.events.eventserviceorchestrator.persistence.dbo.EventHistoryDbo;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EventHistoryDboRepository extends ReactiveCrudRepository<EventHistoryDbo, Long> {
}
