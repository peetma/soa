package ee.ria.events.eventserviceorchestrator.persistence;

import ee.ria.events.eventserviceorchestrator.core.model.EventProcess;
import ee.ria.events.eventserviceorchestrator.core.service.port.persistence.EventProcessPersistencePort;
import ee.ria.events.eventserviceorchestrator.persistence.mapper.EventProcessDboMapper;
import ee.ria.events.eventserviceorchestrator.persistence.repository.EventProcessDboRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Repository
@RequiredArgsConstructor
public class EventProcessPersistenceAdapter implements EventProcessPersistencePort {

  private final EventProcessDboRepository repository;
  private final EventProcessDboMapper mapper;

  @Override
  public Mono<EventProcess> save(EventProcess process) {
    return repository.save(mapper.toDbo(process)).map(mapper::toModel);
  }

  @Override
  public Mono<Long> findId(UUID processId, String serviceCode, String personCode) {
    return repository.findId(processId, serviceCode, personCode);
  }

}
