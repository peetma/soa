package ee.ria.events.eventserviceorchestrator.core.usecase;

import ee.ria.events.eventserviceorchestrator.core.model.EventHistory;
import ee.ria.events.eventserviceorchestrator.core.service.port.persistence.EventHistoryPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class SaveLifeEvent {

  private final EventHistoryPersistencePort eventHistoryPort;

  @Transactional
  public Mono<EventHistory> execute(String lifeEventJson) {
    return eventHistoryPort.save(lifeEventJson);
  }

}
