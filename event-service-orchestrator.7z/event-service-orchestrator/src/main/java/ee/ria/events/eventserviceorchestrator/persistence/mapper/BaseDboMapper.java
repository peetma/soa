package ee.ria.events.eventserviceorchestrator.persistence.mapper;

import io.r2dbc.postgresql.codec.Json;
import org.mapstruct.Named;

public interface BaseDboMapper<E, M> {

  M toModel(E entity);

  E toDbo(M model);

  @Named("objectToJson")
  default Json objectToJson(Object object) {
    return object == null ? null : JsonMapper.toJson(object);
  }

}
