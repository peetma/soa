package ee.ria.events.eventserviceorchestrator.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import ee.ria.events.eventserviceorchestrator.api.v1.context.EventProcessService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(value = "app.zeebe.enabled", havingValue = "true", matchIfMissing = true)
public class LifeEventReceivedConsumer {

  private final EventProcessService processService;
  private final ObjectMapper objectMapper;
  private static final String CREATE_OR_FIND_PROCESS = "create_or_find_event_process";
  @Transactional
  @SneakyThrows()
  @RabbitListener(queues = "${app.queues.lifeEventReceived}", ackMode = "MANUAL")
  public Mono<Void> processLifeEventMessage(Message message) {
    log.info("Processing received life event message: {}", message.getMessageProperties());
    try {
      JsonNode lifeEventJson = objectMapper.readTree(message.getBody());

      Map<String, Object> zeebePayload = Map.of("lifeEvent", lifeEventJson);
      var process = processService.startProcess(CREATE_OR_FIND_PROCESS, zeebePayload);
      return Mono.fromCompletionStage(process).map(result -> {
        var eventProcessId = result.getVariablesAsMap().get("eventProcessId");
        log.info("BPMN Process {} ended successfully with saved or found processId: {}", CREATE_OR_FIND_PROCESS, eventProcessId);
        return result;
      }).then();
    } catch (JsonProcessingException e) {
      log.error("JSON not readable from queue payload");
      throw new RuntimeException(e);
    }
  }
}
