package ee.ria.events.eventserviceorchestrator.persistence;

import ee.ria.events.eventserviceorchestrator.core.service.port.api.CurrentUserPort;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.ReactiveAuditorAware;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class CurrentUserProvider implements ReactiveAuditorAware<String> {

  private final CurrentUserPort currentUserPort;

  @Override
  public Mono<String> getCurrentAuditor() {
    return currentUserPort.getPersonalCode();
  }

}
