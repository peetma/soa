package ee.ria.events.eventserviceorchestrator.core.usecase;

import ee.ria.events.eventserviceorchestrator.core.exception.EventProcessNotFoundException;
import ee.ria.events.eventserviceorchestrator.core.service.port.persistence.EventProcessPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class FindEventProcess {

  private final EventProcessPersistencePort processPort;

  public Mono<Long> execute(UUID processId, String serviceCode, String personCode) {
    return processPort.findId(processId, serviceCode, personCode)
        .switchIfEmpty(Mono.error(new EventProcessNotFoundException()));
  }

}
