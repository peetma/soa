package ee.ria.events.eventserviceorchestrator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration()
public class FeatureConfig {

  @Value("${app.features.START_PROCESS_QUEUE_FEATURE.enabled}")
  private Boolean isStartProcessQueueFeatureEnabled;

  @Bean
  public Boolean getIsStartProcessQueueFeatureEnabled() {
    return isStartProcessQueueFeatureEnabled;
  }

}
