package ee.ria.events.eventserviceorchestrator.core.service.port.api;

import reactor.core.publisher.Mono;

public interface CurrentUserPort {

  Mono<String> getPersonalCode();

}
