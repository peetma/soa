package ee.ria.events.eventserviceorchestrator.api.v1.context;

import ee.ria.events.eventserviceorchestrator.core.service.port.api.EventProcessPort;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.response.ProcessInstanceResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "app.zeebe.enabled", havingValue = "true", matchIfMissing = true)
public class EventProcessService implements EventProcessPort {
  private final ZeebeClient zeebeClient;

  @Override
  public ZeebeFuture<ProcessInstanceResult> startProcess(String processId, Map<String, Object> variables) {
    log.info("Starting process {} with variables {}", processId, variables);

    return zeebeClient
        .newCreateInstanceCommand()
        .bpmnProcessId(processId)
        .latestVersion()
        .variables(variables)
        .withResult()
        .send();
  }

  @PreDestroy
  public void close() {
    if (zeebeClient != null) {
      zeebeClient.close();
      log.info("Zeebe client closed");
    }
  }

}
