package ee.ria.events.eventserviceorchestrator.config;

import io.camunda.zeebe.client.ZeebeClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(value = "app.zeebe.enabled", havingValue = "true", matchIfMissing = true)
public class ZeebeConfig {

  @Bean
  public ZeebeClient zeebeClient(@Value("${zeebe.address:Define property 'zeebe.address'!}") String address) {
    return ZeebeClient.newClientBuilder()
        .gatewayAddress(address)
        .usePlaintext()
        .build();
  }

}
