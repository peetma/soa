package ee.ria.events.eventserviceorchestrator.api.v1.context;

import reactor.core.publisher.Mono;
import reactor.util.context.Context;

public class UserContextHolder {

  private static final Class<UserContext> USER_CONTEXT_KEY = UserContext.class;

  public static Mono<UserContext> getContext() {
    return Mono.deferContextual(Mono::just)
        .cast(Context.class)
        .filter(UserContextHolder::hasUserContext)
        .flatMap(UserContextHolder::getUserContext);
  }

  private static boolean hasUserContext(Context context) {
    return context.hasKey(USER_CONTEXT_KEY);
  }

  private static Mono<UserContext> getUserContext(Context context) {
    return context.<Mono<UserContext>>get(USER_CONTEXT_KEY);
  }

  public static Context withUserContext(Mono<? extends UserContext> userContext) {
    return Context.of(USER_CONTEXT_KEY, userContext);
  }
}
