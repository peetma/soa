package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class GeneralConfig {
  String name;
  String description;
  String mobileHelpText;
  String keywords;
}
