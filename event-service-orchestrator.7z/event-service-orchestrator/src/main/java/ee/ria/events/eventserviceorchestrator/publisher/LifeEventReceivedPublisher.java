package ee.ria.events.eventserviceorchestrator.publisher;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LifeEventReceivedPublisher {

  private final RabbitTemplate rabbitTemplate;
  private final String lifeEventRecievedQueue;

  public LifeEventReceivedPublisher(
      RabbitTemplate rabbitTemplate,
      @Value("${app.queues.lifeEventReceived}") String lifeEventRecievedQueue) {
    this.rabbitTemplate = rabbitTemplate;
    this.lifeEventRecievedQueue = lifeEventRecievedQueue;
  }

  public void sendMessage(Message message) {
    var messageId = message.getMessageProperties().getMessageId();
    var correlationData = new CorrelationData();
    correlationData.setId(messageId);

    rabbitTemplate.convertAndSend(lifeEventRecievedQueue, message, correlationData);

    log.info("Sent life event message {}", messageId);
  }

}
