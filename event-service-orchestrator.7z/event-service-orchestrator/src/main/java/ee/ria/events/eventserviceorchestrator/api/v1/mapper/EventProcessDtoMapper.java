package ee.ria.events.eventserviceorchestrator.api.v1.mapper;

import ee.ria.events.eventserviceorchestrator.core.model.EventProcess;
import ee.ria.events.eventserviceorchestrator.openapigenerate.model.EventProcessDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface EventProcessDtoMapper
    extends BaseDtoMapper<EventProcessDto, EventProcess> {
}
