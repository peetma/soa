package ee.ria.events.eventserviceorchestrator.persistence.dbo;

import io.r2dbc.postgresql.codec.Json;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "event_process")
public class EventProcessDbo extends Auditable {

  @Id
  private Long id;
  private UUID processId;
  private UUID parentProcessId;
  private String personCode;
  private Json processSetup;
  private Json steps;

}
