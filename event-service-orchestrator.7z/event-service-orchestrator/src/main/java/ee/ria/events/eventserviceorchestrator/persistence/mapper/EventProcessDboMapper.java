package ee.ria.events.eventserviceorchestrator.persistence.mapper;

import ee.ria.events.eventserviceorchestrator.core.model.EventProcess;
import ee.ria.events.eventserviceorchestrator.persistence.dbo.EventProcessDbo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface EventProcessDboMapper extends BaseDboMapper<EventProcessDbo, EventProcess> {

  @Override
  @Mapping(source = "processSetup", target = "processSetup", qualifiedByName = "objectToJson")
  @Mapping(source = "steps", target = "steps", qualifiedByName = "objectToJson")
  EventProcessDbo toDbo(EventProcess model);

}
