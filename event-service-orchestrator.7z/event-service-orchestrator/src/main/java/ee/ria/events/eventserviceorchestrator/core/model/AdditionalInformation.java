package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AdditionalInformation implements Serializable {

  private String et;
  private String en;
  private String ru;
  private String headingEt;
  private String headingEn;
  private String headingRu;
}
