package ee.ria.events.eventserviceorchestrator.persistence.repository;

import ee.ria.events.eventserviceorchestrator.persistence.dbo.EventProcessDbo;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Repository
public interface EventProcessDboRepository extends ReactiveCrudRepository<EventProcessDbo, Long> {

  @Query("SELECT id FROM event_process WHERE process_id = :processId " +
      "AND person_code = :personCode " +
      "AND UPPER(process_setup->>'serviceCode') = UPPER(:serviceCode)")
  Mono<Long> findId(UUID processId, String serviceCode, String personCode);

}
