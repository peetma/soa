package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class StepConfig {
  String title;
  String relativeUrl;
  Integer mainArticleId;
  String contentArticlesTitle;
  List<Integer> contentArticleIds;
  String referenceArticlesTitle;
  List<Integer> referenceArticleIds;
  Integer contactArticleId;
  String actionsTitle;
  List<Action> actions;
  List<Notification> notifications;
}
