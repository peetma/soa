package ee.ria.events.eventserviceorchestrator.core.service.port.persistence;

import ee.ria.events.eventserviceorchestrator.core.model.EventHistory;
import reactor.core.publisher.Mono;

public interface EventHistoryPersistencePort {

  Mono<EventHistory> save(String lifeEventJson);

}
