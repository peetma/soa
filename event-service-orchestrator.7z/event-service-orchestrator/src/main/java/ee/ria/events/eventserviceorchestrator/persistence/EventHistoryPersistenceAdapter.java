package ee.ria.events.eventserviceorchestrator.persistence;

import ee.ria.events.eventserviceorchestrator.core.model.EventHistory;
import ee.ria.events.eventserviceorchestrator.core.service.port.persistence.EventHistoryPersistencePort;
import ee.ria.events.eventserviceorchestrator.persistence.dbo.EventHistoryDbo;
import ee.ria.events.eventserviceorchestrator.persistence.mapper.EventHistoryDboMapper;
import ee.ria.events.eventserviceorchestrator.persistence.repository.EventHistoryDboRepository;
import io.r2dbc.postgresql.codec.Json;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
@RequiredArgsConstructor
public class EventHistoryPersistenceAdapter implements EventHistoryPersistencePort {

  private final EventHistoryDboRepository repository;
  private final EventHistoryDboMapper mapper;

  @Override
  public Mono<EventHistory> save(String lifeEventJson) {
    return repository.save(EventHistoryDbo.builder().event(Json.of(lifeEventJson)).build()).map(mapper::toModel);
  }
}
