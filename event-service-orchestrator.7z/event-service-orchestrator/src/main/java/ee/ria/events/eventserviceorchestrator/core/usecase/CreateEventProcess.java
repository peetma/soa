package ee.ria.events.eventserviceorchestrator.core.usecase;

import ee.ria.events.eventserviceorchestrator.core.model.EventProcess;
import ee.ria.events.eventserviceorchestrator.core.service.port.persistence.EventProcessPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class CreateEventProcess {

  private final EventProcessPersistencePort processPort;

  @Transactional
  public Mono<Long> execute(EventProcess process) {
    return processPort.save(process).map(EventProcess::getId);
  }

}
