package ee.ria.events.eventserviceorchestrator.api.v1.context;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class UserContextFilter implements WebFilter {

  private static final ObjectMapper objectMapper = new ObjectMapper();

  public static final String AUTHENTICATED_USER_HEADER = "X-Authenticated-User";

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    return chain.filter(exchange)
        .contextWrite(UserContextHolder.withUserContext(Mono.just(createUserContext(exchange))));
  }

  private static UserContext createUserContext(ServerWebExchange exchange) {
    String authenticatedUserHeader = getAuthenticatedUserHeader(exchange);
    if (StringUtils.isBlank(authenticatedUserHeader)) {
      return new UserContext(null);
    }
    return new UserContext(authenticatedUserHeader);
  }

  private static String getAuthenticatedUserHeader(ServerWebExchange exchange) {
    return exchange.getRequest().getHeaders().getFirst(AUTHENTICATED_USER_HEADER);
  }
}
