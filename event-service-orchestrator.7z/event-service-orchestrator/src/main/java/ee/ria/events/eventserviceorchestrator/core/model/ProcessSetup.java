package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Value
@Builder
public class ProcessSetup {
  Integer serviceSetupVersionId;
  Integer serviceSetupId;
  String serviceCode;
  LocalDate startDate;
  ServiceOwner owner;
  Map<String, String> relativeUrls;
  List<ProcessSetupLocalization> localizations;
}

