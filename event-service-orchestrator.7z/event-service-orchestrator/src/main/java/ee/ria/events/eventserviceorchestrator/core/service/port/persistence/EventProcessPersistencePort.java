package ee.ria.events.eventserviceorchestrator.core.service.port.persistence;

import ee.ria.events.eventserviceorchestrator.core.model.EventProcess;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface EventProcessPersistencePort {

  Mono<EventProcess> save(EventProcess process);

  Mono<Long> findId(UUID processId, String serviceCode, String personCode);

}
