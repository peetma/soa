package ee.ria.events.eventserviceorchestrator.api.v1.mapper;

public interface BaseDtoMapper<E, M> {

  E toDto(M model);

  M toModel(E dto);

}
