package ee.ria.events.eventserviceorchestrator.api.v1.context;

import lombok.Value;

@Value
public class UserContext {
  String personalCode;
}
