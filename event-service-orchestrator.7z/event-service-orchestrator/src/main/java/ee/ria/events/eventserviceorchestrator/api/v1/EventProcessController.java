package ee.ria.events.eventserviceorchestrator.api.v1;

import ee.ria.events.eventserviceorchestrator.api.v1.mapper.EventProcessDtoMapper;
import ee.ria.events.eventserviceorchestrator.core.usecase.CreateEventProcess;
import ee.ria.events.eventserviceorchestrator.core.usecase.FindEventProcess;
import ee.ria.events.eventserviceorchestrator.openapigenerate.EventProcessApi;
import ee.ria.events.eventserviceorchestrator.openapigenerate.model.EventProcessDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
public class EventProcessController implements EventProcessApi {

  private final CreateEventProcess createEventProcess;
  private final FindEventProcess findEventProcess;
  private final EventProcessDtoMapper mapper;

  @Override
  public Mono<ResponseEntity<Long>> create(String xAuthenticatedUser,
                                           Mono<EventProcessDto> eventProcessDto,
                                           final ServerWebExchange exchange) {
    return eventProcessDto
        .map(mapper::toModel)
        .flatMap(createEventProcess::execute)
        .map(id -> ResponseEntity.status(HttpStatus.CREATED).body(id));
  }

  @Override
  public Mono<ResponseEntity<Long>> find(
      UUID processId, String serviceCode, String personCode, final ServerWebExchange exchange
  ) {
    return findEventProcess.execute(processId, serviceCode, personCode)
        .map(ResponseEntity::ok)
        .defaultIfEmpty(ResponseEntity.status(HttpStatus.NO_CONTENT).build())
        .onErrorResume(error -> Mono.just(ResponseEntity.status(HttpStatus.NO_CONTENT).build()));
  }

}
