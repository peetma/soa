package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

import java.util.UUID;

@Value
@Builder
public class EventProcess {
  Long id;
  UUID processId;
  UUID parentProcessId;
  String personCode;
  ProcessSetup processSetup;
  Object steps;
}
