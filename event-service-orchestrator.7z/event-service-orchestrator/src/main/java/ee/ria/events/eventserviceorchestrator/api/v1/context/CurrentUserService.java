package ee.ria.events.eventserviceorchestrator.api.v1.context;

import ee.ria.events.eventserviceorchestrator.core.service.port.api.CurrentUserPort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class CurrentUserService implements CurrentUserPort {

  @Override
  public Mono<String> getPersonalCode() {
    return UserContextHolder.getContext()
        .map(UserContext::getPersonalCode);
  }

}
