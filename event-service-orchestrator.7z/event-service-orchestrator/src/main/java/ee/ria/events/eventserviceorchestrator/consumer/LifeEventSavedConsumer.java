package ee.ria.events.eventserviceorchestrator.consumer;

import ee.ria.events.eventserviceorchestrator.config.FeatureConfig;
import ee.ria.events.eventserviceorchestrator.core.usecase.SaveLifeEvent;
import ee.ria.events.eventserviceorchestrator.publisher.LifeEventReceivedPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
@Slf4j
public class LifeEventSavedConsumer {

  private final SaveLifeEvent saveLifeEvent;
  private final LifeEventReceivedPublisher lifeEventReceivedPublisher;
  private final FeatureConfig featureConfig;

  @Transactional
  @RabbitListener(queues = "${app.queues.lifeEventSaved}", ackMode = "MANUAL")
  public Mono<Void> saveLifeEventMessage(Message message) {
    log.info("Saving life event message: {}", message);

    var lifeEventJson = new String(message.getBody());

    return saveLifeEvent.execute(lifeEventJson)
        .flatMap(eventHistory -> {
          Long id = eventHistory.getId();
          byte[] payload = message.getBody();

          var properties = new MessageProperties();
          properties.setMessageId(id.toString());
          var newMessage = new Message(payload, properties);

          if (featureConfig.getIsStartProcessQueueFeatureEnabled()) {
            log.info("Sending life event message to received event queue");
            lifeEventReceivedPublisher.sendMessage(newMessage);
          }

          return Mono.empty();
        })
        .then();
  }

}
