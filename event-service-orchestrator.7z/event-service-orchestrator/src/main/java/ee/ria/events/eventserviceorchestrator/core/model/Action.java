package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class Action {
  String infoBoxTitle;
  String infoBoxDescription;
  String buttonText;
  String url;
  String returnUrl;
  String returnUrlCode;
  String imageName;
}
