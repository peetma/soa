package ee.ria.events.eventserviceorchestrator.persistence.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.r2dbc.postgresql.codec.Json;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class JsonMapper {

  private static final ObjectMapper MAPPER = new ObjectMapper();

  static {
    MAPPER.registerModule(new JavaTimeModule());
    MAPPER.configure(WRITE_DATES_AS_TIMESTAMPS, false);
  }

  public static Json toJson(Object object) {
    try {
      return Json.of(MAPPER.writeValueAsString(object));
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
  }
}
