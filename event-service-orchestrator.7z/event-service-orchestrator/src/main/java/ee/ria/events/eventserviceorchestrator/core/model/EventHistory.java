package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class EventHistory {
  Long id;
  Object event;
}
