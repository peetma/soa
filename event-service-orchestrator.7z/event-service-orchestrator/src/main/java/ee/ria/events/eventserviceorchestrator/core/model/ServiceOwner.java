package ee.ria.events.eventserviceorchestrator.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ServiceOwner {
  String registerCode;
  String name;
  String contactPersonName;
  String email;
  String phoneNumber;
}

