package ee.ria.events.eventserviceorchestrator.persistence.mapper;

import ee.ria.events.eventserviceorchestrator.core.model.EventHistory;
import ee.ria.events.eventserviceorchestrator.persistence.dbo.EventHistoryDbo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface EventHistoryDboMapper extends BaseDboMapper<EventHistoryDbo, EventHistory> {

  @Override
  @Mapping(source = "event", target = "event", qualifiedByName = "objectToJson")
  EventHistoryDbo toDbo(EventHistory model);

}
