package ee.ria.events.eventserviceorchestrator.core.exception;

public class EventProcessNotFoundException extends RuntimeException {
}
