package ee.ria.events.eventserviceorchestrator.core.service.port.api;

import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.response.ProcessInstanceResult;

import java.util.Map;

public interface EventProcessPort {

  ZeebeFuture<ProcessInstanceResult> startProcess(String processId, Map<String, Object> variables);

}
