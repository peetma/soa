package ee.ria.events.eventserviceorchestrator.it.fitnesse.formatters;

import fitnesse.reporting.BaseFormatter;
import fitnesse.testsystems.TestPage;
import fitnesse.testsystems.TestSummary;
import fitnesse.testsystems.TestSystem;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

@RequiredArgsConstructor
public class RecordingFormatter extends BaseFormatter {

  public static final String HTML_SEPARATOR = "<hr/>";
  public static final String WIKI_SEPARATOR = "----";

  private final Properties properties;

  private Path inRoot;
  private Path outRoot;
  private String recordedHtml;
  private boolean multiChunkRecordingStarted;
  private boolean outputStarted;

  @Override
  @SneakyThrows
  public void testSystemStarted(TestSystem testSystem) {
    final Path rootPath = Paths.get(properties.getProperty("FITNESSE_ROOTPATH"));

    inRoot = rootPath.resolve("FitNesseRoot");
    outRoot = rootPath.resolve("recorded");

    FileUtils.deleteDirectory(outRoot.toFile());
  }

  @Override
  public void testStarted(TestPage testPage) {
    recordedHtml = null;
    multiChunkRecordingStarted = false;
    outputStarted = false;
  }

  @Override
  public void testOutputChunk(TestPage page, String output) {
    if (!multiChunkRecordingStarted && output.contains(HTML_SEPARATOR)) {
      multiChunkRecordingStarted = true;
      recordedHtml = output.split(HTML_SEPARATOR, 2)[1];
      return;
    }

    if (multiChunkRecordingStarted) {
      recordedHtml = recordedHtml + output;
    } else {
      recordedHtml = output;
    }
  }

  @Override
  @SneakyThrows
  public void testComplete(TestPage testPage, TestSummary summary) {
    if (summary.getExceptions() > 0 || summary.getWrong() == 0) {
      return;
    }

    final String wikiPath = testPage.getFullPath();

    final Path filePath = Paths.get(wikiPath.replace('.', '/') + ".wiki");

    final String recordedWiki = FormatterUtils.htmlToWiki(recordedHtml);
    final String firstRecordedLine = stripped(recordedWiki.split("\n", 2)[0]);
    final Path inPath = inRoot.resolve(filePath);

    final Path outPath = outRoot.resolve(filePath);
    Files.createDirectories(outPath.getParent());

    try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(outPath))) {
      copyUntilFirstRecordedLine(inPath, firstRecordedLine, writer);
      writer.println(recordedWiki);
    }
  }

  private void copyUntilFirstRecordedLine(Path inPath, String firstRecordedLine, PrintWriter writer) throws IOException {
    if (!multiChunkRecordingStarted) {
      outputStarted = true;
    }
    Files.lines(inPath)
        .takeWhile(e -> {
          if (!outputStarted && WIKI_SEPARATOR.equals(e)) {
            outputStarted = true;
          }
          return !(outputStarted && stripped(e).equals(firstRecordedLine));
        })
        .forEach(writer::println);
  }

  private String stripped(String s) {
    return s.replace(" ", "");
  }

}
