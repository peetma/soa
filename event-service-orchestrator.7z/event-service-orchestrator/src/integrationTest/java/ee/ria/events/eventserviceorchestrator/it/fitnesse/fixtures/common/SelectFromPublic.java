package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.FitnesseContextHolder;
import ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.base.BaseSelectFrom;
import org.springframework.jdbc.core.JdbcTemplate;

import static ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common.Constants.PUBLIC_SCHEMA_NAME;

public class SelectFromPublic extends BaseSelectFrom {

  public SelectFromPublic(String tableName) {
    this(tableName, null);
  }

  public SelectFromPublic(String tableName, String where) {
    super(FitnesseContextHolder.bean(JdbcTemplate.class), PUBLIC_SCHEMA_NAME, tableName, where);
  }
}
