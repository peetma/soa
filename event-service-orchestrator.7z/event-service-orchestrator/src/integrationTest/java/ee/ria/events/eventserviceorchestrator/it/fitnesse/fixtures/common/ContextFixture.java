package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.FitnesseContextHolder;

public class ContextFixture {

  public void clearContext() {
    FitnesseContextHolder.clear();
  }

  public String getUniqueSuffix() {
    return String.valueOf(System.currentTimeMillis());
  }
}
