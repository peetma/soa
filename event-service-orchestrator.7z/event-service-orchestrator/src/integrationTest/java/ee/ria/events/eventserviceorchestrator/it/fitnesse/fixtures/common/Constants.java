package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common;

public class Constants {

  public static final String PUBLIC_SCHEMA_NAME = "PUBLIC";

  private Constants() {
  }
}
