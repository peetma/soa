package ee.ria.events.eventserviceorchestrator.it.fitnesse.plugins;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.formatters.RecordingFormatter;
import ee.ria.events.eventserviceorchestrator.it.fitnesse.symbol.UniqueSymbolType;
import fitnesse.plugins.PluginFeatureFactory;
import fitnesse.reporting.FormatterRegistry;
import fitnesse.wikitext.parser.SymbolProvider;

public class CustomFitnessePlugin implements PluginFeatureFactory {

  @Override
  public void registerSymbolTypes(SymbolProvider symbolProvider) {
    symbolProvider.add(new UniqueSymbolType());
  }

  @Override
  public void registerFormatters(FormatterRegistry registrar) {
    registrar.registerFormatter(RecordingFormatter.class);
  }
}
