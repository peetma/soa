package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.FitnesseContextHolder;
import ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.base.BaseInsertInto;
import org.springframework.jdbc.core.JdbcTemplate;

import static ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common.Constants.PUBLIC_SCHEMA_NAME;

public class InsertIntoPublic extends BaseInsertInto {

  public InsertIntoPublic(String tableName) {
    super(FitnesseContextHolder.bean(JdbcTemplate.class), PUBLIC_SCHEMA_NAME, tableName);
  }

}
