package ee.ria.events.eventserviceorchestrator.it.fitnesse;

public interface UseCase<T, R> {

  R execute(T command);

}
