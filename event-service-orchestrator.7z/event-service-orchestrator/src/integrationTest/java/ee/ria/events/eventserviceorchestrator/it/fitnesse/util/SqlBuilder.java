package ee.ria.events.eventserviceorchestrator.it.fitnesse.util;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class SqlBuilder {
  private final String schema;
  private final String table;

  public String insert(List<String> columns) {
    return "INSERT INTO " + table() + parens(columns(columns)) + " VALUES " + parens(placeholders(columns));
  }

  public String update(List<String> columns, String where) {
    return "UPDATE " + table() + " SET " + columns(columns) + " = " + parens(placeholders(columns)) + " WHERE " + where;
  }

  public String select(List<String> columns) {
    return "SELECT " + columns(columns) + " FROM " + table();
  }

  public String select(List<String> columns, String where) {
    String select = select(columns);

    if (StringUtils.isBlank(where)) {
      return select;
    }

    return select + " WHERE " + where;
  }

  public String delete() {
    return "DELETE FROM " + table();
  }

  public String truncateCascade() {
    return "TRUNCATE " + table() + " CASCADE";
  }

  private String placeholders(List<String> columns) {
    return columns.stream()
        .map(this::placeholder)
        .collect(Collectors.joining(", "));
  }

  private String placeholder(String column) {
    List<String> jsonColumns = List.of("process_setup", "steps");
    if (jsonColumns.contains(column)) {
      return "cast(? AS JSON)";
    }
    return "?";
  }

  private String parens(String string) {
    return "(" + string + ")";
  }

  private String columns(List<String> columns) {
    return String.join(", ", columns);
  }

  private String table() {
    return schema + "." + table;
  }

}
