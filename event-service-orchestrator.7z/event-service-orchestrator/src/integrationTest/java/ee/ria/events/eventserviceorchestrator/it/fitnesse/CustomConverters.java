package ee.ria.events.eventserviceorchestrator.it.fitnesse;

import fitnesse.slim.converters.ConverterBase;
import fitnesse.slim.converters.ConverterRegistry;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CustomConverters {

  public static void init() {
    ConverterRegistry.addConverter(BigDecimal.class, new BigDecimalConverter());
    ConverterRegistry.addConverter(LocalDate.class, new LocalDateConverter());
  }

  private static class BigDecimalConverter extends ConverterBase<BigDecimal> {
    private static final DecimalFormat DF = decimalFormat();

    private static DecimalFormat decimalFormat() {
      DecimalFormatSymbols dfs = new DecimalFormatSymbols();
      dfs.setDecimalSeparator(',');
      dfs.setMinusSign('-');

      DecimalFormat df = new DecimalFormat();
      df.setDecimalFormatSymbols(dfs);
      df.setMinimumFractionDigits(2);
      df.setMaximumFractionDigits(Integer.MAX_VALUE);
      df.setGroupingUsed(false);
      df.setParseBigDecimal(true);
      return df;
    }

    @Override
    protected BigDecimal getObject(String arg) {
      try {
        return (BigDecimal) DF.parseObject(arg);
      } catch (ParseException e) {
        throw new RuntimeException(e);
      }
    }

    @Override
    protected String getString(BigDecimal o) {
      return DF.format(o);
    }
  }

  private static class LocalDateConverter extends ConverterBase<LocalDate> {
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    @Override
    protected LocalDate getObject(String arg) {
      return LocalDate.parse(arg, DTF);
    }

    @Override
    protected String getString(LocalDate o) {
      return o.format(DTF);
    }
  }

  private CustomConverters() {
  }
}
