package ee.ria.events.eventserviceorchestrator.it.fitnesse.symbol;

import fitnesse.wikitext.parser.Matcher;
import fitnesse.wikitext.parser.Maybe;
import fitnesse.wikitext.parser.Parser;
import fitnesse.wikitext.parser.Rule;
import fitnesse.wikitext.parser.Symbol;
import fitnesse.wikitext.parser.SymbolType;
import fitnesse.wikitext.parser.Translation;
import fitnesse.wikitext.parser.Translator;

import static java.text.MessageFormat.format;

public class UniqueSymbolType extends SymbolType implements Rule, Translation {
  public UniqueSymbolType() {
    super("Unique");
    wikiMatcher(new Matcher().string("!unique["));
    wikiRule(this);
    htmlTranslation(this);
  }

  @Override
  public Maybe<Symbol> parse(Symbol current, Parser parser) {
    Symbol text = parser.parseTo(SymbolType.CloseBracket);
    current.add(text);
    return new Maybe<>(current);
  }

  @Override
  public String toTarget(Translator translator, Symbol symbol) {
    return format("{0}#{1,number,#}", symbol.childAt(0).childAt(0).getContent(), System.currentTimeMillis());
  }
}
