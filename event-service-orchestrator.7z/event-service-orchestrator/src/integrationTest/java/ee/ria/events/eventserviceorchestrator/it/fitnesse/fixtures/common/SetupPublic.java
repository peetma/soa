package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.FitnesseContextHolder;
import ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.base.BaseSetup;
import org.springframework.jdbc.core.JdbcTemplate;

import static ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.common.Constants.PUBLIC_SCHEMA_NAME;

public class SetupPublic extends BaseSetup {
  public SetupPublic() {
    super(FitnesseContextHolder.bean(JdbcTemplate.class), PUBLIC_SCHEMA_NAME);
  }
}
