package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.base;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.util.SqlBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;

@RequiredArgsConstructor
public abstract class BaseSetup {
  private final JdbcTemplate jdbcTemplate;
  private final String schemaName;

  public void truncateCascade(String tableName) {
    String truncate = new SqlBuilder(schemaName, tableName).truncateCascade();
    jdbcTemplate.execute(truncate);
  }
}
