package ee.ria.events.eventserviceorchestrator.it.fitnesse.util;

import java.util.List;

public class EmptyTableBuilder {

  public static List<List<String>> emptyTable(List<List<String>> table) {
    return table.stream()
        .map(e -> List.<String>of())
        .toList();
  }

}
