package ee.ria.events.eventserviceorchestrator.it.fitnesse.fixtures.base;

import ee.ria.events.eventserviceorchestrator.it.fitnesse.util.SqlBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static ee.ria.events.eventserviceorchestrator.it.fitnesse.util.BatchArgumentsBuilder.batchInsertArguments;
import static ee.ria.events.eventserviceorchestrator.it.fitnesse.util.EmptyTableBuilder.emptyTable;

@Slf4j
@RequiredArgsConstructor
public abstract class BaseInsertInto {

  private final JdbcTemplate jdbcTemplate;
  private final String schemaName;
  private final String tableName;

  public List<List<String>> doTable(List<List<String>> table) {
    if (table.size() >= 2) {
      List<String> columns = table.get(0);
      List<List<String>> values = table.subList(1, table.size());
      jdbcTemplate.batchUpdate(insertSql(columns), batchInsertArguments(columns, values));
    }
    return emptyTable(table);
  }

  private String insertSql(List<String> columns) {
    return new SqlBuilder(schemaName, tableName).insert(columns);
  }

}
