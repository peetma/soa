package ee.ria.events.eventserviceorchestrator.it.fitnesse.util;

import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

public class BatchArgumentsBuilder {

  public static List<Object[]> batchInsertArguments(List<String> columns, List<List<String>> values) {
    return values.stream()
        .map(row -> convert(columns, row))
        .toList();
  }

  private static Object[] convert(List<String> columns, List<String> row) {
    return IntStream
        .range(0, row.size())
        .mapToObj(index -> convert(columns.get(index), row.get(index)))
        .toArray();
  }

  private static Object convert(String key, String value) {
    if (StringUtils.equals(StringUtils.trim(value), "null")) {
      return null;
    }
    if ("id".equals(key)) {
      return Long.valueOf(value);
    }
    if (key.endsWith("_id")) {
      return UUID.fromString(value);
    }
    return value;
  }

}
