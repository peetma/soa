##PORT FORWARD Zeebe & Zeebe Monitor
kubectl -n sun port-forward svc/camunda-platform-zeebe-zeebe-gateway 26500:26500 & \
kubectl -n sun port-forward service/camunda-platform-zeebe-simple-monitor 8082:8082 &
