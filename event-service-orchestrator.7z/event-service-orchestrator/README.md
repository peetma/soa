# Event Service Orchestrator
[![Quality Gate Status](https://sonarqube.riaint.ee/api/project_badges/measure?project=SUN.event-service-orchestrator&metric=alert_status&token=61dfda20f53cb0ebe22bc27aca4bc92a6ad8bd39)](https://sonarqube.riaint.ee/dashboard?id=SUN.event-service-orchestrator)

## Features
* Spring Boot 2.7.1
* Java 17
* PostgresSQL implementation of R2DBC
* Liquibase
* Lombok

## How to run:
* Use <b>docker-compose up</b> & <b>docker-compose down</b> to run the database and pgAdmin;
* Run via gradle command or set local profile to <b>local</b> and run directly from intellij;

### URLs
Swagger: http://localhost:8106/event-service-orchestrator/swagger-ui.html
