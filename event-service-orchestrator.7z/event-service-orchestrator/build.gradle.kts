import com.google.cloud.tools.jib.gradle.JibExtension
import org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
import org.gradle.api.tasks.testing.logging.TestLogEvent.FAILED
import org.gradle.api.tasks.testing.logging.TestLogEvent.PASSED
import org.gradle.api.tasks.testing.logging.TestLogEvent.SKIPPED
import org.owasp.dependencycheck.gradle.extension.AnalyzerExtension
import org.springframework.boot.gradle.dsl.SpringBootExtension

plugins {
  java
  pmd
  checkstyle
  jacoco
  id("org.springframework.boot")
  id("io.spring.dependency-management")
  id("org.openapi.generator")
  id("com.google.cloud.tools.jib")
  id("org.unbroken-dome.test-sets")
  id("com.github.spotbugs")
  id("jacoco")
  id("org.sonarqube")
  id("org.owasp.dependencycheck")
  id("pl.allegro.tech.build.axion-release")
}

group = "ee.ria.events"

scmVersion {
  versionCreator("versionWithBranch")
  tag {
    prefix.set("")
  }
}

project.version = scmVersion.version

java.sourceCompatibility = JavaVersion.VERSION_17

configurations {
  compileOnly {
    extendsFrom(configurations.annotationProcessor.get())
  }
}

repositories {
  maven {
    url = uri("https://nexus.riaint.ee/repository/maven-public/")
    metadataSources {
      mavenPom()
      artifact()
      ignoreGradleMetadataRedirection()
    }
  }
}

testSets {
  val integrationTest by creating
}

val integrationTestImplementation by configurations
val integrationTestCompileOnly by configurations
val integrationTestAnnotationProcessor by configurations

val integrationTest by tasks.existing(Test::class) {
  useJUnitPlatform()
  testLogging {
    events(PASSED, SKIPPED, FAILED)
    exceptionFormat = FULL
  }
  defaultCharacterEncoding = "UTF-8"
}

tasks.withType<Test> {
  useJUnitPlatform()
}

dependencies {
  implementation("org.springframework.boot:spring-boot-starter-actuator")
  implementation("org.springframework.boot:spring-boot-starter-amqp")
  implementation("org.springframework.boot:spring-boot-starter-data-r2dbc")
  implementation("org.springframework.boot:spring-boot-starter-webflux")
  implementation("org.springframework.boot:spring-boot-starter-amqp")
  implementation("org.liquibase:liquibase-core")
  implementation("org.mapstruct:mapstruct:_")
  compileOnly("org.projectlombok:lombok")
  developmentOnly("org.springframework.boot:spring-boot-devtools")

  implementation("org.springdoc:springdoc-openapi-starter-webflux-api:_")
  implementation("org.springdoc:springdoc-openapi-starter-webflux-ui:_")
  implementation("org.openapitools:jackson-databind-nullable:_")
  implementation("io.swagger.core.v3:swagger-annotations:_")
  implementation("javax.validation:validation-api:_")
  implementation("javax.annotation:javax.annotation-api:_")

  implementation("ch.qos.logback.contrib:logback-json-classic:_")
  implementation("ch.qos.logback.contrib:logback-jackson:_")

  runtimeOnly("org.postgresql:postgresql")
  implementation("org.postgresql:r2dbc-postgresql")
  annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
  annotationProcessor("org.projectlombok:lombok")
  annotationProcessor("org.mapstruct:mapstruct-processor:_")

  implementation("com.fasterxml.jackson.core:jackson-databind")
  implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:_")
  implementation("com.vladmihalcea:hibernate-types-60:_")

  implementation("io.camunda:zeebe-client-java:_")

  integrationTestImplementation("org.springframework.boot:spring-boot-starter-test")
  integrationTestImplementation("org.springframework.boot:spring-boot-starter-jdbc")
  integrationTestImplementation("io.projectreactor:reactor-test")
  integrationTestImplementation("org.springframework.amqp:spring-rabbit-test")
  integrationTestImplementation("org.fitnesse:fitnesse:_")
  integrationTestImplementation("org.htmlparser:htmlparser:_")
  integrationTestImplementation("commons-io:commons-io:_")
  integrationTestImplementation("org.junit.vintage:junit-vintage-engine:_")

  integrationTestCompileOnly("org.projectlombok:lombok")
  integrationTestAnnotationProcessor("org.projectlombok:lombok")

  testImplementation(Testing.junit.jupiter)
  testImplementation("org.mockito:mockito-core:_")
  testImplementation("org.mockito:mockito-junit-jupiter:_")
  testImplementation("org.assertj:assertj-core:_")
  testImplementation("io.projectreactor:reactor-test")
}

configurations {
  integrationTestImplementation.exclude(module = "spring-boot-starter-logging")
  integrationTestImplementation.exclude(group = "ch.qos.logback.contrib")
}

configure<SpringBootExtension> {
  buildInfo()
}

configure<JibExtension> {
  from {
    image = "nexus.riaint.ee:8500/openjdk:21-slim"
  }
  to {
    image = "riaee/sun-event-service-orchestrator"
    tags = setOf(project.version.toString(), "latest")
    auth {
      username = "${project.findProperty("registryUsername")}"
      password = "${project.findProperty("registryPassword")}"
    }
  }
  container {
    mainClass = "ee.ria.events.eventserviceorchestrator.EventServiceOrchestratorApplication"
    user = "nobody" // Non-root user
  }
}

val basePackageName = "ee.ria.events.eventserviceorchestrator.openapigenerate"
val modelPackageName = "$basePackageName.model"

openApiGenerate {
  library.set("spring-boot")
  generatorName.set("spring")
  inputSpec.set("$projectDir/src/main/resources/api-docs-v3.yaml")
  outputDir.set("$projectDir/src/main/gen")
  modelPackage.set(modelPackageName)
  apiPackage.set(basePackageName)
  modelNameSuffix.set("Dto")
  generateApiTests.set(false)

  generateModelTests.set(false)

  configOptions.set(
      mapOf(
          "reactive" to "true",
          "delegatePattern" to "true",
          "interfaceOnly" to "true",
          "java8" to "true",
          "dateLibrary" to "java8",
          "useTags" to "true",
          "sourceFolder" to ""  // makes IDEs like IntelliJ more reliably interpret the class packages.
      )
  )
}

pmd {
  toolVersion = "6.54.0"
  isIgnoreFailures = true
  ruleSets = emptyList<String>()
  ruleSetFiles = files("$rootDir/etc/pmd-ruleset.xml")
}

checkstyle {
  toolVersion = "10.9.3"
  configFile = rootProject.file("$rootDir/etc/checkstyle.xml")
}

spotbugs {
  ignoreFailures.set(true)
  excludeFilter.set(file("$rootDir/etc/spotbugs-exclude.xml"))
}

tasks.spotbugsMain {
  reports.create("html") {
    required.set(true)
    outputLocation.set(file("$buildDir/reports/spotbugs.html"))
    setStylesheet("fancy-hist.xsl")
  }
}

jacoco {
  toolVersion = "0.8.8"
}

tasks.jacocoTestCoverageVerification {
  dependsOn(integrationTest)

  executionData(files("$buildDir/jacoco/integrationTest.exec"))
  violationRules {
    rule {
      limit {
        minimum = BigDecimal.valueOf(0.4)
      }
    }
  }
}

tasks.jacocoTestReport {
  dependsOn(integrationTest)

  executionData(files("$buildDir/jacoco/integrationTest.exec"))
  reports {
    xml.required.set(true)
  }
}

sonarqube {
  val baseDir = projectDir
  val sonarTestSources = mutableListOf<String>()
  sonarTestSources.add("src/integrationTest")
  val testDirs = sonarTestSources.filter { baseDir.resolve(it).exists() }.joinToString()

  properties {
    property("sonar.projectName", "SUN.event-service-orchestrator")
    property("sonar.projectKey", "SUN.event-service-orchestrator")
    property("sonar.dependencyCheck.jsonReportPath", "build/reports/dependency-check-report.json")
    property("sonar.dependencyCheck.htmlReportPath", "build/reports/dependency-check-report.html")
    property("sonar.sourceEncoding", "UTF-8")
    property("sonar.tests", testDirs)
    property("sonar.host.url", "https://sonarqube.riaint.ee")
    property("sonar.analysisCache.enabled", false)
  }
}

dependencyCheck {
  failBuildOnCVSS = 7F
  format = "ALL"
  analyzers(closureOf<AnalyzerExtension> {
    nodeEnabled = false
    assemblyEnabled = false
    nodeAuditEnabled = false
  })

  hostedSuppressions(closureOf<org.owasp.dependencycheck.gradle.extension.HostedSuppressionsExtension> {
    enabled = false
  })

  cveValidForHours = 24
  data(closureOf<org.owasp.dependencycheck.gradle.extension.DataExtension> {
    directory = "/opt/riajenk/sun-owasp-dependecy-check"
  })

  suppressionFile = "etc/dep-check-supressions.xml"
}

java.sourceSets["main"].java {
  srcDir("src/main/gen")
}

tasks.findByName("compileJava")?.dependsOn(tasks.findByName("openApiGenerate"))
