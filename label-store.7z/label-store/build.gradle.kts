import com.google.cloud.tools.jib.gradle.JibExtension
import org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
import org.gradle.api.tasks.testing.logging.TestLogEvent.FAILED
import org.gradle.api.tasks.testing.logging.TestLogEvent.PASSED
import org.gradle.api.tasks.testing.logging.TestLogEvent.SKIPPED
import org.owasp.dependencycheck.gradle.extension.AnalyzerExtension
import org.springframework.boot.gradle.dsl.SpringBootExtension

plugins {
  pmd
  checkstyle
  jacoco
  id("org.springframework.boot")
  id("io.spring.dependency-management")
  id("java")
  id("com.google.cloud.tools.jib")
  id("org.unbroken-dome.test-sets")
  id("io.freefair.lombok")
  id("com.github.spotbugs")
  id("org.sonarqube")
  id("org.owasp.dependencycheck")
  id("pl.allegro.tech.build.axion-release")
}

group = "ee.ria.events"

scmVersion {
  versionCreator("versionWithBranch")
  tag {
    prefix.set("")
  }
}

project.version = scmVersion.version
configure<JavaPluginExtension> {
  sourceCompatibility = JavaVersion.VERSION_17
}

repositories {
  maven("https://nexus.riaint.ee/repository/maven-public/")
}


testSets {
  val integrationTest by creating
}

val testImplementation by configurations
val integrationTestImplementation by configurations

tasks.test {
  useJUnitPlatform()
  testLogging {
    events(
        PASSED,
        SKIPPED,
        FAILED
    )
    exceptionFormat = FULL
  }
}

val integrationTest by tasks.existing(Test::class) {
  useJUnitPlatform()
  testLogging {
    events(
        PASSED,
        SKIPPED,
        FAILED
    )
    exceptionFormat = FULL
  }
}

dependencies {
  implementation("org.springframework.boot:spring-boot-starter-data-r2dbc")
  implementation("org.springframework.boot:spring-boot-starter-webflux")
  implementation("org.springframework.boot:spring-boot-starter-jdbc")
  implementation("org.springframework.boot:spring-boot-starter-actuator")

  implementation("org.mapstruct:mapstruct:_")
  implementation("org.liquibase:liquibase-core:_")
  implementation("io.r2dbc:r2dbc-postgresql:_")
  implementation("org.springframework.data:spring-data-r2dbc")
  implementation("org.springdoc:springdoc-openapi-starter-webflux-api:_")
  implementation("org.springdoc:springdoc-openapi-starter-webflux-ui:_")
  implementation("com.googlecode.owasp-java-html-sanitizer:owasp-java-html-sanitizer:_")
  implementation("net.javacrumbs.shedlock:shedlock-spring:_")
  implementation("net.javacrumbs.shedlock:shedlock-provider-r2dbc:_")
  implementation("ch.qos.logback.contrib:logback-json-classic:_")
  implementation("ch.qos.logback.contrib:logback-jackson:_")

  runtimeOnly("org.postgresql:postgresql")

  annotationProcessor("org.mapstruct:mapstruct-processor:_")

  testImplementation(Testing.junit.jupiter)
  testImplementation("org.assertj:assertj-core:_")

  integrationTestImplementation("org.springframework.boot:spring-boot-starter-test")
  integrationTestImplementation("org.springframework.boot:spring-boot-starter-jdbc")
  integrationTestImplementation("io.projectreactor:reactor-test")
  integrationTestImplementation("org.fitnesse:fitnesse:_")
  integrationTestImplementation("org.htmlparser:htmlparser:_")
  integrationTestImplementation("commons-io:commons-io:_")
  integrationTestImplementation("org.junit.vintage:junit-vintage-engine:_")
}

configurations {
  integrationTestImplementation.exclude(module = "spring-boot-starter-logging")
  integrationTestImplementation.exclude(group = "ch.qos.logback.contrib")
}

configure<SpringBootExtension> {
  buildInfo()
}

configure<JibExtension> {
  from {
    image = "nexus.riaint.ee:8500/openjdk:21-slim"
  }
  to {
    image = "riaee/sun-label-store"
    tags = setOf(project.version.toString(), "latest")
    auth {
      username = "${project.findProperty("registryUsername")}"
      password = "${project.findProperty("registryPassword")}"
    }
  }
  container {
    mainClass = "ee.ria.events.labelstore.LabelStoreApplication"
    user = "nobody" // Non-root user
  }
}

pmd {
  toolVersion = "6.48.0"
  isIgnoreFailures = true
  ruleSets = emptyList<String>()
  ruleSetFiles = files("$rootDir/etc/pmd-ruleset.xml")
}

checkstyle {
  toolVersion = "10.9.3"
  configFile = rootProject.file("$rootDir/etc/checkstyle/checkstyle.xml")
}

spotbugs {
  ignoreFailures.set(true)
  excludeFilter.set(file("$rootDir/etc/spotbugs-exclude.xml"))
}

tasks.spotbugsMain {
  reports.create("html") {
    required.set(true)
    outputLocation.set(file("$buildDir/reports/spotbugs.html"))
    setStylesheet("fancy-hist.xsl")
  }
}

jacoco {
  toolVersion = "0.8.8"
}

tasks.jacocoTestCoverageVerification {
  dependsOn(tasks.test)
  dependsOn(integrationTest)

  executionData(files("$buildDir/jacoco/test.exec", "$buildDir/jacoco/integrationTest.exec"))
  violationRules {
    rule {
      limit {
        minimum = BigDecimal.valueOf(0.4)
      }
    }
  }
}

tasks.jacocoTestReport {
  dependsOn(tasks.test)
  dependsOn(integrationTest)

  executionData(files("$buildDir/jacoco/test.exec", "$buildDir/jacoco/integrationTest.exec"))
  reports {
    xml.required.set(true)
  }
}

sonarqube {
  val baseDir = projectDir
  val sonarTestSources = mutableListOf<String>()
  sonarTestSources.add("src/test")
  sonarTestSources.add("src/integrationTest")
  val testDirs = sonarTestSources.filter { baseDir.resolve(it).exists() }.joinToString()

  properties {
    property("sonar.projectName", "SUN.label-store")
    property("sonar.projectKey", "SUN.label-store")
    property("sonar.dependencyCheck.jsonReportPath", "build/reports/dependency-check-report.json")
    property("sonar.dependencyCheck.htmlReportPath", "build/reports/dependency-check-report.html")
    property("sonar.sourceEncoding", "UTF-8")
    property("sonar.tests", testDirs)
    property("sonar.host.url", "https://sonarqube.riaint.ee")
    property("sonar.analysisCache.enabled", false)
  }
}

dependencyCheck {
  failBuildOnCVSS = 7F
  format = "ALL"
  analyzers(closureOf<AnalyzerExtension> {
    nodeEnabled = false
    assemblyEnabled = false
    nodeAuditEnabled = false
  })

  hostedSuppressions(closureOf<org.owasp.dependencycheck.gradle.extension.HostedSuppressionsExtension> {
    enabled = false
  })

  cveValidForHours = 24
  data(closureOf<org.owasp.dependencycheck.gradle.extension.DataExtension> {
    directory = "/opt/riajenk/sun-owasp-dependecy-check"
  })

  suppressionFile = "dep-check-supressions.xml"
}
