package ee.ria.events.labelstore.v1;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static org.springframework.http.ResponseEntity.status;

@Order
@Slf4j
@ControllerAdvice
public class DefaultRestExceptionHandler {

  @ExceptionHandler(Exception.class)
  public ResponseEntity<Void> handleException(Exception exception) {
    log.error("Service failed", exception);
    return status(HttpStatus.INTERNAL_SERVER_ERROR).build();
  }

}
