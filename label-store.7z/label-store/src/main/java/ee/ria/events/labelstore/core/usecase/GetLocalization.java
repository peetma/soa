package ee.ria.events.labelstore.core.usecase;

import ee.ria.events.labelstore.core.exception.UnsupportedLanguageException;
import ee.ria.events.labelstore.core.model.Language;
import ee.ria.events.labelstore.core.model.Localization;
import ee.ria.events.labelstore.core.service.port.persistence.LocalizationPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

@Component
@RequiredArgsConstructor
public class GetLocalization {

  private final LocalizationPersistencePort port;

  public Flux<Localization> execute(String language) {
    Language lang = Language.fromString(language)
        .orElseThrow(UnsupportedLanguageException::new);

    return port.get(lang);
  }

}
