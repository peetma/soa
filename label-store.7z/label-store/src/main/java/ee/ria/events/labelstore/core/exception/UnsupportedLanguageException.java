package ee.ria.events.labelstore.core.exception;

public class UnsupportedLanguageException extends RuntimeException {
}
