package ee.ria.events.labelstore.persistence.mapper;

import ee.ria.events.labelstore.core.model.Localization;
import ee.ria.events.labelstore.persistence.entity.LocalizationDbo;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface LocalizationDboMapper {

  Localization toModel(LocalizationDbo entity);

}
