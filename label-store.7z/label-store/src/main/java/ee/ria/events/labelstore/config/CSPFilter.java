package ee.ria.events.labelstore.config;

import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import org.springframework.web.util.pattern.PathPattern;
import org.springframework.web.util.pattern.PathPatternParser;
import reactor.core.publisher.Mono;

@Component
public class CSPFilter implements WebFilter {

  private final PathPattern swaggerPathPattern = new PathPatternParser().parse("/webjars/swagger-ui/index.html");
  private static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    String policy = swaggerPathPattern.matches(exchange.getRequest().getPath().pathWithinApplication())
        ? "default-src 'self'; img-src 'self' data: https:; frame-ancestors 'none'"
        : "default-src 'none'; frame-ancestors 'none'";

    exchange.getResponse().getHeaders()
        .set(CONTENT_SECURITY_POLICY, policy);

    return chain.filter(exchange);
  }
}
