package ee.ria.events.labelstore.persistence.entity;

import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("localization")
public class LocalizationDbo {
  String label;
  String language;
  String value;
}
