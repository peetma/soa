package ee.ria.events.labelstore.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.Status;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequiredArgsConstructor
@RequestMapping("/internal/health")
public class HealthController {

  private final HealthEndpoint healthEndpoint;

  @GetMapping
  public Mono<Status> getHealthStatus() {
    return Mono.fromCallable(() -> healthEndpoint.healthForPath("liveness"))
        .map(HealthComponent::getStatus)
        .subscribeOn(Schedulers.boundedElastic());
  }
}
