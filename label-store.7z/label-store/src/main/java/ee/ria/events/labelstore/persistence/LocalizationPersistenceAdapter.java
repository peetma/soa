package ee.ria.events.labelstore.persistence;

import ee.ria.events.labelstore.core.model.Language;
import ee.ria.events.labelstore.core.model.Localization;
import ee.ria.events.labelstore.core.service.port.persistence.LocalizationPersistencePort;
import ee.ria.events.labelstore.persistence.mapper.LocalizationDboMapper;
import ee.ria.events.labelstore.persistence.repository.LocalizationDboRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
@RequiredArgsConstructor
public class LocalizationPersistenceAdapter implements LocalizationPersistencePort {

  private final LocalizationDboRepository repository;
  private final LocalizationDboMapper mapper;

  @Override
  public Flux<Localization> get(Language language) {
    return repository.findByLanguage(language.name().toLowerCase()).map(mapper::toModel);
  }
}
