package ee.ria.events.labelstore.persistence.repository;

import ee.ria.events.labelstore.persistence.entity.LocalizationDbo;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface LocalizationDboRepository extends ReactiveCrudRepository<LocalizationDbo, String> {

  Flux<LocalizationDbo> findByLanguage(String language);

}
