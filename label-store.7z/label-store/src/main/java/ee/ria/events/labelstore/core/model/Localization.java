package ee.ria.events.labelstore.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class Localization {
  String label;
  String language;
  String value;
}
