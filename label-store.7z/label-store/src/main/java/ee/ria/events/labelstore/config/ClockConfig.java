package ee.ria.events.labelstore.config;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.ZoneId;
import java.util.TimeZone;

@Configuration
public class ClockConfig {
  public static final ZoneId ZONE_ID = ZoneId.of("Europe/Helsinki");

  @PostConstruct
  void setTimeZone() {
    TimeZone.setDefault(TimeZone.getTimeZone(ZONE_ID));
  }

  @Bean
  public Clock clock() {
    return Clock.system(ZONE_ID);
  }

}
