package ee.ria.events.labelstore.core.model;

import java.util.EnumSet;
import java.util.Optional;

public enum Language {
  ET, EN, RU;

  public static Optional<Language> fromString(String language) {
    return EnumSet.allOf(Language.class).stream()
        .filter(lang -> lang.name().equalsIgnoreCase(language))
        .findFirst();
  }
}
