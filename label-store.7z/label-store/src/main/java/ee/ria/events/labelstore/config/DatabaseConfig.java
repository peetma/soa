package ee.ria.events.labelstore.config;

import io.r2dbc.pool.PoolingConnectionFactoryProvider;
import io.r2dbc.postgresql.PostgresqlConnectionConfiguration;
import io.r2dbc.postgresql.PostgresqlConnectionFactory;
import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import io.r2dbc.spi.Option;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;
import org.springframework.lang.NonNull;
import org.springframework.r2dbc.connection.R2dbcTransactionManager;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class DatabaseConfig extends AbstractR2dbcConfiguration {

  @Value("${database.name}")
  private String database;

  @Value("${database.host}")
  private String host;

  @Value("${database.port:5432}")
  private int port;

  @Value("${database.app.username}")
  private String username;

  @Value("${database.app.password}")
  private String password;

  @Value("${database.sslMode}")
  private String sslMode;

  @Value("${database.poolSize}")
  private int poolSize;

  @Override
  @Bean
  @NonNull
  public ConnectionFactory connectionFactory() {
    return ConnectionFactories.get(ConnectionFactoryOptions.builder()
        .option(ConnectionFactoryOptions.DRIVER, "pool")
        .option(ConnectionFactoryOptions.PROTOCOL, "postgresql")
        .option(ConnectionFactoryOptions.HOST, host)
        .option(ConnectionFactoryOptions.PORT, port)
        .option(ConnectionFactoryOptions.USER, username)
        .option(ConnectionFactoryOptions.PASSWORD, password)
        .option(ConnectionFactoryOptions.DATABASE, database)
        .option(Option.valueOf("sslMode"), sslMode)
        .option(PoolingConnectionFactoryProvider.MAX_SIZE, poolSize)
        .build());
  }

  @Bean
  ReactiveTransactionManager transactionManager(ConnectionFactory connectionFactory) {
    // To use @Transactional annotation, you have to declare a ReactiveTransactionManager bean, Spring provides an implementation for R2dbc
    return new R2dbcTransactionManager(connectionFactory);
  }

}
