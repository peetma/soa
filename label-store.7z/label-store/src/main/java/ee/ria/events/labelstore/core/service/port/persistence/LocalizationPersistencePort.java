package ee.ria.events.labelstore.core.service.port.persistence;

import ee.ria.events.labelstore.core.model.Language;
import ee.ria.events.labelstore.core.model.Localization;
import reactor.core.publisher.Flux;

public interface LocalizationPersistencePort {

  Flux<Localization> get(Language language);

}
