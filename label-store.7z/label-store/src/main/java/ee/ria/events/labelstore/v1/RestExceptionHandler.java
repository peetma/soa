package ee.ria.events.labelstore.v1;

import ee.ria.events.labelstore.core.exception.UnsupportedLanguageException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static org.springframework.http.ResponseEntity.notFound;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RestExceptionHandler {

  @ExceptionHandler(UnsupportedLanguageException.class)
  public ResponseEntity<Void> handleUnsupportedLanguageException() {
    return notFound().build();
  }

}
