--liquibase formatted sql

--changeset sarah:create_localization_table
create table if not exists localization
(
    label    text       NOT NULL,
    language varchar(2) NOT NULL,
    value    text       NOT NULL,
    created  timestamp  NOT NULL DEFAULT current_timestamp,
    modified timestamp  NOT NULL DEFAULT current_timestamp,
    constraint pk_localization primary key (label, language)
)
--rollback DROP TABLE public.localization

--changeset sarah:add_localization_table_indexes
CREATE INDEX idx_localization_language ON localization (language);
--rollback DROP INDEX IF EXISTS idx_localization_language;
