--liquibase formatted sql

--changeset siimv:update_localization_data runOnChange:true
UPDATE localization
SET value = 'Последнее изменение'
WHERE label = 'article.modified' AND language = 'ru';
--rollback DELETE FROM localization;
