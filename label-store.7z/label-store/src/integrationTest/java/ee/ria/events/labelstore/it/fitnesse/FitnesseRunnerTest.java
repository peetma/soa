package ee.ria.events.labelstore.it.fitnesse;

import fitnesse.junit.FitNesseRunner;
import org.junit.runner.RunWith;

@RunWith(FitNesseRunner.class)
@FitNesseRunner.Suite("IntegrationSuite")
@FitNesseRunner.FitnesseDir("src/integrationTest/fitnesse")
@FitNesseRunner.OutputDir("build/reports/fitnesse")
public class FitnesseRunnerTest {
}
