package ee.ria.events.labelstore.it.fitnesse.fixtures.base;

import ee.ria.events.labelstore.it.fitnesse.util.SqlBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static fitnesse.slim.converters.ElementConverterHelper.elementToString;

@RequiredArgsConstructor
public abstract class BaseSelectFrom {
  private final JdbcTemplate jdbcTemplate;
  private final String schemaName;
  private final String tableName;
  private final String where;

  private List<String> columns;

  public void table(List<List<String>> table) {
    this.columns = table.get(0);
  }

  public List<List<List<String>>> query() {
    List<Map<String, Object>> mapList = jdbcTemplate.queryForList(selectSql());

    return mapList.stream()
        .map(this::mapToList)
        .collect(Collectors.toList());
  }

  private String selectSql() {
    return new SqlBuilder(schemaName, tableName).select(columns, where);
  }

  private List<List<String>> mapToList(Map<String, Object> map) {
    return map.entrySet().stream()
        .map(e -> List.of(e.getKey(), convert(e.getValue())))
        .collect(Collectors.toList());
  }

  private String convert(Object value) {
    return elementToString(value);
  }

}
