package ee.ria.events.labelstore.it.fitnesse.usecase;

import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UseCaseFactory {

  private final ApplicationContext applicationContext;

  @SuppressWarnings("unchecked")
  public <U> U create(Class<U> usecaseClass) {
    return (U) fromBean(usecaseClass);
  }

  private Object fromBean(Class<?> usecaseClass) {
    try {
      return applicationContext.getBean(usecaseClass);
    } catch (Exception e) {
      return null;
    }
  }

}
