package ee.ria.events.labelstore.it.fitnesse;

import ee.ria.events.labelstore.LabelStoreApplication;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

public class FitnesseContext {
  private final ApplicationContext applicationContext = createApplicationContext();
  private final Map<Class<?>, Object> map = new HashMap<>();

  private static ApplicationContext createApplicationContext() {
    return new SpringApplicationBuilder(LabelStoreApplication.class)
        .profiles("test", "default")
        .run();
  }

  public <T> T bean(Class<T> clazz) {
    return applicationContext.getBean(clazz);
  }

  public <T> T bean(String name, Class<T> clazz) {
    return applicationContext.getBean(name, clazz);
  }

  private <T> T create(Class<T> clazz) {
    return applicationContext
        .getAutowireCapableBeanFactory()
        .createBean(clazz);
  }

  public void clear() {
    map.clear();
  }

  @SuppressWarnings("unchecked")
  public <T> T shared(Class<T> clazz) {
    return (T) map.computeIfAbsent(clazz, this::create);
  }

  public <T> T copy(Class<T> clazz) {
    T original = shared(clazz);
    T copy = create(clazz);

    BeanUtils.copyProperties(original, copy);

    return copy;
  }
}
