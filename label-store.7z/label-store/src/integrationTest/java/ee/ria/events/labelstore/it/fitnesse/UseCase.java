package ee.ria.events.labelstore.it.fitnesse;

public interface UseCase<T, R> {

  R execute(T command);

}
