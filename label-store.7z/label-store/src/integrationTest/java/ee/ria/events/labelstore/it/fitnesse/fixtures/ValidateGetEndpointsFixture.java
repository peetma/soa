package ee.ria.events.labelstore.it.fitnesse.fixtures;

import ee.ria.events.labelstore.it.fitnesse.fixtures.base.UseCaseFixture;
import ee.ria.events.labelstore.it.fitnesse.usecase.controllers.ValidateGetEndpoints;
import ee.ria.events.labelstore.it.fitnesse.usecase.controllers.ValidateGetEndpoints.Input;
import ee.ria.events.labelstore.it.fitnesse.usecase.controllers.ValidateGetEndpoints.Output;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Delegate;

import static lombok.AccessLevel.PROTECTED;

@Getter(PROTECTED)
@Setter(PROTECTED)
public class ValidateGetEndpointsFixture extends UseCaseFixture<ValidateGetEndpoints, Input, Output> {

  @Delegate
  private Input input;

  @Delegate
  private Output output;

}
