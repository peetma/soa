package ee.ria.events.labelstore.it.fitnesse.fixtures.base;

import ee.ria.events.labelstore.it.fitnesse.util.SqlBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static ee.ria.events.labelstore.it.fitnesse.util.BatchArgumentsBuilder.batchInsertArguments;
import static ee.ria.events.labelstore.it.fitnesse.util.EmptyTableBuilder.emptyTable;

@Slf4j
@RequiredArgsConstructor
public abstract class BaseUpdate {
  private final JdbcTemplate jdbcTemplate;
  private final String schemaName;
  private final String tableName;
  private final String where;

  public List<List<String>> doTable(List<List<String>> table) {
    if (table.size() >= 2) {
      List<String> columns = table.get(0);
      List<List<String>> values = table.subList(1, table.size());
      jdbcTemplate.batchUpdate(updateSql(columns, where), batchInsertArguments(columns, values));
    }

    return emptyTable(table);
  }

  private String updateSql(List<String> columns, String where) {
    return new SqlBuilder(schemaName, tableName).update(columns, where);
  }

}
