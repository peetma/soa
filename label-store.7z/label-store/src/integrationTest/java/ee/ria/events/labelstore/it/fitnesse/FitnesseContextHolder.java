package ee.ria.events.labelstore.it.fitnesse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FitnesseContextHolder {

  private static final FitnesseContext CONTEXT;

  static {
    try {
      CustomConverters.init();
      CONTEXT = new FitnesseContext();
    } catch (Throwable e) {
      log.error("Error while initializing FitnesseContextHolder:", e);
      throw new RuntimeException(e);
    }
  }

  public static <T> T bean(Class<T> clazz) {
    return CONTEXT.bean(clazz);
  }

  public static <T> T bean(String name, Class<T> clazz) {
    return CONTEXT.bean(name, clazz);
  }

  public static <T> T shared(Class<T> clazz) {
    return CONTEXT.shared(clazz);
  }

  public static <T> T copy(Class<T> clazz) {
    return CONTEXT.copy(clazz);
  }

  public static void clear() {
    CONTEXT.clear();
  }

  private FitnesseContextHolder() {
  }
}
