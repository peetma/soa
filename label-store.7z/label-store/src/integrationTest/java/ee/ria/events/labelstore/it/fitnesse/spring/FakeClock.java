package ee.ria.events.labelstore.it.fitnesse.spring;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.experimental.Delegate;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.Instant;

@Primary
@Component
@RequiredArgsConstructor
public class FakeClock extends Clock {
  private final Clock realClock;

  @Delegate
  private Clock delegate;

  @PostConstruct
  public void reset() {
    delegate = realClock;
  }

  public void set(Instant time) {
    delegate = fixed(time, delegate.getZone());
  }
}
