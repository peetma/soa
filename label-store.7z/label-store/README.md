# Label Store API
[![Quality Gate Status](https://sonarqube.riaint.ee/api/project_badges/measure?project=SUN.label-store&metric=alert_status&token=1a65906999d34a7d1a5257c79b6da637266774f8)](https://sonarqube.riaint.ee/dashboard?id=SUN.label-store)

## Features
* Spring Boot 3.0.0
* Java 17
* PostgresSQL implementation of R2DBC
* Liquibase
* Lombok
* Swagger

## How to run:
* Use docker-compose up to run database and docker-compose down to stop it.
* Run via gradle command or directly from intellij;

### URLs
Swagger: http://localhost:8104/label-store/swagger-ui.html
