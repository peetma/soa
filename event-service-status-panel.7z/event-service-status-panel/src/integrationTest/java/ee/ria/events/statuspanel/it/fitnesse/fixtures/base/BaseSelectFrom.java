package ee.ria.events.statuspanel.it.fitnesse.fixtures.base;

import ee.ria.events.statuspanel.it.fitnesse.util.SqlBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static fitnesse.slim.converters.ElementConverterHelper.elementToString;

@RequiredArgsConstructor
public abstract class BaseSelectFrom {
  private final JdbcTemplate jdbcTemplate;
  private final String schemaName;
  private final String tableName;
  private final String where;

  private List<String> columns;

  public void table(List<List<String>> table) {
    this.columns = table.get(0);
  }

  public List<List<List<String>>> query() {
    List<Map<String, Object>> mapList = jdbcTemplate.queryForList(selectSql());

    return mapList.stream()
        .map(this::mapToList)
        .collect(Collectors.toList());
  }

  private String selectSql() {
    return new SqlBuilder(schemaName, tableName).select(columns, where);
  }

  private List<List<String>> mapToList(Map<String, Object> map) {
    return map.entrySet().stream()
        .map(e -> List.of(e.getKey(), convert(e.getValue())))
        .collect(Collectors.toList());
  }

  private String convert(Object value) {
    if (value instanceof Timestamp timestamp) {
      return elementToString(timestamp.toLocalDateTime().toInstant(ZoneOffset.UTC));
    }
    if (value instanceof Date date) {
      return date.toLocalDate().format(DateTimeFormatter.ISO_DATE);
    }
    return elementToString(value);
  }

}
