package ee.ria.events.statuspanel.it.fitnesse.fixtures.common;

public class Constants {

  public static final String PUBLIC_SCHEMA_NAME = "PUBLIC";

  private Constants() {
  }
}
