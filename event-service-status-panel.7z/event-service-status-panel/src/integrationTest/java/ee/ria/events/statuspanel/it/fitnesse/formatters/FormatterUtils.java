package ee.ria.events.statuspanel.it.fitnesse.formatters;

import lombok.experimental.UtilityClass;
import org.htmlparser.Node;
import org.htmlparser.Parser;
import org.htmlparser.Tag;
import org.htmlparser.Text;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.lexer.Lexer;
import org.htmlparser.tags.Span;
import org.htmlparser.tags.TableColumn;
import org.htmlparser.tags.TableRow;
import org.htmlparser.tags.TableTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;
import org.htmlparser.util.SimpleNodeIterator;

import java.util.Iterator;

/**
 * Based on Apache 2.0 licenced code from
 * https://github.com/fitnesse/idea-fitnesse/blob/master/idea-fitnesse_rt/src/main/java/fitnesse/idea/rt/IntelliJFormatter.java
 */
@UtilityClass
class FormatterUtils {
  private static final String NEWLINE = System.getProperty("line.separator");

  public static String htmlToWiki(String output) {
    try {
      NodeList nodes = new Parser(new Lexer(output)).parse(null);
      return translate(nodes).trim();
    } catch (ParserException e) {
      throw new RuntimeException(e);
    }
  }

  private static String translate(NodeList nodes) {
    StringBuilder sb = new StringBuilder();
    translate(nodes, sb);
    return sb.toString()
        .replace("[", "")
        .replace("] surplus", "")
        .replaceAll("] expected .*", "");
  }

  private static void translate(NodeList nodes, StringBuilder sb) {
    if (nodes == null) {
      return;
    }

    for (Node node : nodeListIterator(nodes)) {
      if (node instanceof TableTag) {
        sb.append(translateTable(node.getChildren()));
      } else if (node instanceof Span span) {
        if (!"ignore".equals(span.getAttribute("class"))) {
          sb.append(span.getChildrenHTML());
        }
      } else if (node instanceof Tag && "BR".equals(((Tag) node).getTagName())) {
        sb.append(NEWLINE);
      } else if (node.getChildren() != null) {
        translate(node.getChildren(), sb);
      } else if (node instanceof Text) {
        sb.append(node.getText());
      }
    }
  }

  private static String translateTable(NodeList nodes) {
    StringBuilder sb = new StringBuilder();
    for (Node row : rowIterator(nodes)) {
      for (Node cell : columnIterator(row)) {
        sb.append("|").append(translate(cell.getChildren()));
      }
      sb.append("|\n");
    }
    return sb.toString().trim();
  }

  private static Iterable<Node> columnIterator(Node row) {
    return nodeListIterator(row.getChildren().extractAllNodesThatMatch(new NodeClassFilter(TableColumn.class)));
  }

  private static Iterable<Node> rowIterator(NodeList nodes) {
    return nodeListIterator(nodes.extractAllNodesThatMatch(new NodeClassFilter(TableRow.class)));
  }

  private static Iterable<Node> nodeListIterator(NodeList nodes) {
    final SimpleNodeIterator iter = nodes.elements();
    return () -> new Iterator<>() {
      @Override
      public boolean hasNext() {
        return iter.hasMoreNodes();
      }

      @Override
      public Node next() {
        return iter.nextNode();
      }

      @Override
      public void remove() {
        throw new IllegalStateException("NodeList iterator.remove() should not have been called");
      }
    };
  }
}
