package ee.ria.events.statuspanel.it.fitnesse.util;

import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.IntStream;

public class BatchArgumentsBuilder {

  public static List<Object[]> batchInsertArguments(List<String> columns, List<List<String>> values) {
    return values.stream()
        .map(row -> convert(columns, row))
        .toList();
  }

  private static Object[] convert(List<String> columns, List<String> row) {
    return IntStream
        .range(0, row.size())
        .mapToObj(index -> convert(columns.get(index), row.get(index)))
        .toArray();
  }

  private static Object convert(String key, String value) {
    if (StringUtils.equals(StringUtils.trim(value), "null")) {
      return null;
    }
    if ("id".equals(key) || key.endsWith("_id")) {
      return Integer.valueOf(value);
    }
    if ("start_date".equals(key)) {
      return LocalDate.parse(value);
    }
    if ("modified".equals(key)) {
      return LocalDateTime.ofInstant(Instant.parse(value), ZoneId.of("Europe/Tallinn"));
    }
    if ("version".equals(key)) {
      return Long.valueOf(value);
    }
    if ("deleted".equals(key)) {
      return Boolean.valueOf(value);
    }
    return value;
  }

}
