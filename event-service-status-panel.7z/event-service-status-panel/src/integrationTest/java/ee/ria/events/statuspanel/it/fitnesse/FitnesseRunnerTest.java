package ee.ria.events.statuspanel.it.fitnesse;

import fitnesse.junit.FitNesseRunner;
import org.junit.runner.RunWith;

@RunWith(FitNesseRunner.class)
@FitNesseRunner.Suite("IntegrationSuite")
@FitNesseRunner.FitnesseDir("src/integrationTest/fitnesse")
@FitNesseRunner.OutputDir("build/reports/fitnesse")
public class FitnesseRunnerTest {
}
