package ee.ria.events.statuspanel.it.fitnesse.util;

import java.util.List;
import java.util.stream.Collectors;

public class EmptyTableBuilder {

  public static List<List<String>> emptyTable(List<List<String>> table) {
    return table.stream()
        .map(e -> List.<String>of())
        .collect(Collectors.toList());
  }

}
