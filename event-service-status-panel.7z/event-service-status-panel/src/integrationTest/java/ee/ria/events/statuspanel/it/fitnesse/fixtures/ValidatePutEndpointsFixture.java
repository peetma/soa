package ee.ria.events.statuspanel.it.fitnesse.fixtures;

import ee.ria.events.statuspanel.it.fitnesse.fixtures.base.UseCaseFixture;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidatePutEndpoints;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidatePutEndpoints.Input;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidatePutEndpoints.Output;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Delegate;

import static lombok.AccessLevel.PROTECTED;

@Getter(PROTECTED)
@Setter(PROTECTED)
public class ValidatePutEndpointsFixture extends UseCaseFixture<ValidatePutEndpoints, Input, Output> {

  @Delegate
  private Input input;

  @Delegate
  private Output output;

}
