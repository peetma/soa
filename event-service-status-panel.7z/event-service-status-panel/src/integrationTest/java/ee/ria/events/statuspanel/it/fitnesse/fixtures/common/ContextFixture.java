package ee.ria.events.statuspanel.it.fitnesse.fixtures.common;

import ee.ria.events.statuspanel.it.fitnesse.FitnesseContextHolder;

public class ContextFixture {

  public void clearContext() {
    FitnesseContextHolder.clear();
  }

  public String getUniqueSuffix() {
    return String.valueOf(System.currentTimeMillis());
  }
}
