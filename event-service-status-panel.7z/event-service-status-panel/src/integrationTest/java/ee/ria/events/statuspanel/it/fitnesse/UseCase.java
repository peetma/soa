package ee.ria.events.statuspanel.it.fitnesse;

public interface UseCase<T, R> {

  R execute(T command);

}
