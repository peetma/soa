package ee.ria.events.statuspanel.it.fitnesse.usecase.controllers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;

import static ee.ria.events.statuspanel.rest.v1.context.UserContextFilter.PERSONAL_CODE_HEADER;

@Slf4j
@Component
@WebFluxTest
@RequiredArgsConstructor
public class ValidatePutEndpointsJavaAdapter implements ValidatePutEndpoints {

  @Autowired
  private WebTestClient webTestClient;

  @Override
  public Output execute(Input input) {
    try {
      WebTestClient.RequestHeadersSpec<?> spec = webTestClient.put()
          .uri(input.getEndpoint())
          .contentType(MediaType.APPLICATION_JSON)
          .accept(MediaType.APPLICATION_JSON)
          .body(BodyInserters.fromValue(input.getContentJson()));
      if (input.getPersonalCodeHeader() != null) {
        spec.header(PERSONAL_CODE_HEADER, input.getPersonalCodeHeader());
      }

      WebTestClient.ResponseSpec responseSpec = spec.exchange()
          .expectStatus().isEqualTo(input.getExpectedStatus());
      if (input.getResultJson() != null) {
        responseSpec.expectBody().json(input.getResultJson(), true);
      }
    } catch (Exception e) {
      log.error("Query failed", e);
      return new Output(false);
    }
    return new Output(true);
  }

}
