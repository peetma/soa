package ee.ria.events.statuspanel.it.fitnesse.usecase.controllers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Optional;

import static ee.ria.events.statuspanel.rest.v1.context.UserContextFilter.PERSONAL_CODE_HEADER;

@Slf4j
@Component
@WebFluxTest
@RequiredArgsConstructor
public class ValidateDeleteEndpointsJavaAdapter implements ValidateDeleteEndpoints {

  @Autowired
  private WebTestClient webTestClient;

  @Override
  public Output execute(Input input) {
    try {
      WebTestClient.RequestHeadersSpec<?> spec = webTestClient.delete()
          .uri(input.getEndpoint())
          .accept(MediaType.APPLICATION_JSON);
      if (input.getPersonalCodeHeader() != null) {
        spec.header(PERSONAL_CODE_HEADER, input.getPersonalCodeHeader());
      }

      WebTestClient.ResponseSpec responseSpec = spec.exchange()
          .expectStatus().isEqualTo(input.getExpectedStatus());
      if (input.getResultJson() != null) {
        responseSpec.expectBody().json(Optional.ofNullable(input.getResultJson()).orElse(""), true);
      }

    } catch (AssertionError | Exception e) {
      log.error("Query failed", e);
      return new Output(false);
    }
    return new Output(true);
  }

}
