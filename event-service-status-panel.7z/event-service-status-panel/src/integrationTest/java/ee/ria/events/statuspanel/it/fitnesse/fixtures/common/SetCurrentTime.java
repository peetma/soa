package ee.ria.events.statuspanel.it.fitnesse.fixtures.common;

import ee.ria.events.statuspanel.it.fitnesse.FitnesseContextHolder;
import ee.ria.events.statuspanel.it.fitnesse.spring.FakeClock;

import java.time.Instant;

public class SetCurrentTime {

  private final FakeClock fakeClock = FitnesseContextHolder.bean(FakeClock.class);

  public void setCurrentTime(String time) {
    fakeClock.set(Instant.parse(time));
  }

}
