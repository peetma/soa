package ee.ria.events.statuspanel.it.fitnesse.fixtures;

import ee.ria.events.statuspanel.it.fitnesse.fixtures.base.UseCaseFixture;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidateDeleteEndpoints;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidateDeleteEndpoints.Input;
import ee.ria.events.statuspanel.it.fitnesse.usecase.controllers.ValidateDeleteEndpoints.Output;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Delegate;

import static lombok.AccessLevel.PROTECTED;

@Getter(PROTECTED)
@Setter(PROTECTED)
public class ValidateDeleteEndpointsFixture extends UseCaseFixture<ValidateDeleteEndpoints, Input, Output> {

  @Delegate
  private Input input;

  @Delegate
  private Output output;

}
