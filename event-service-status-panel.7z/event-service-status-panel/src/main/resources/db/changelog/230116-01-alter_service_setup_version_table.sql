--liquibase formatted sql

--changeset sarah:add_column_deleted_to_service_setup_version
ALTER TABLE service_setup_version ADD COLUMN deleted boolean NOT NULL DEFAULT false;

CREATE INDEX idx_service_setup_version_deleted ON service_setup_version(deleted);
--rollback ALTER TABLE public.service_setup_version DROP COLUMN deleted
