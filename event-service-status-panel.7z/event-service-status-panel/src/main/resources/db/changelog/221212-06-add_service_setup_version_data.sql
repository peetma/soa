--liquibase formatted sql

--changeset sarah:add_service_setup_version_data
insert into service_setup_version(id, service_setup_id, start_date, owner) values
  (1, 1, '2022-08-03',
   '{
       "registerCode": "70000562",
       "name": "Siseministeerium",
       "contactPersonName": "Katrin Lehtpuu",
       "email": "katrin.lehtpuu@siseministeerium.ee",
       "phoneNumber": "+372 5331 6044"
    }');
select setval('service_setup_version_id_seq', (select max(id) from service_setup_version));
--rollback DELETE FROM service_setup_version
