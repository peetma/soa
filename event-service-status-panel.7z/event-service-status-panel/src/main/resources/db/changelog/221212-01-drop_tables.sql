--liquibase formatted sql

--changeset sarah:drop_tables
drop table if exists article;
drop table if exists localization;
drop table if exists article_localization;
