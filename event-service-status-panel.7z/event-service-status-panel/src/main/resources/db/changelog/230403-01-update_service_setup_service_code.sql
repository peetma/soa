--liquibase formatted sql

--changeset henrym:update_service_setup
update service_setup set service_code = 'abiellumine' where id = 1;
