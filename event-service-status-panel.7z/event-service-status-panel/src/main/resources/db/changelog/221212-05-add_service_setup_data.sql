--liquibase formatted sql

--changeset sarah:update_service_setup_data
insert into service_setup(id, relative_urls) values
  (1, '{"et": "/abiellumine", "en": "/marriage", "ru": "/zaklucenie-braka"}');
select setval('service_setup_id_seq', (select max(id) from service_setup));
--rollback DELETE FROM service_setup
