--liquibase formatted sql

--changeset sarah:create_service_setup_version_table
create table if not exists service_setup_version
(
  id               serial    CONSTRAINT pk_service_setup_version PRIMARY KEY,
  service_setup_id integer   NOT NULL,
  start_date       date,
  owner            jsonb     NOT NULL,
  created          timestamp NOT NULL DEFAULT current_timestamp,
  created_by       text      NOT NULL DEFAULT 'SYSTEM',
  modified         timestamp NOT NULL DEFAULT current_timestamp,
  modified_by      text      NOT NULL DEFAULT 'SYSTEM',
  CONSTRAINT key_service_setup_version_start_date_service_setup_id UNIQUE(start_date, service_setup_id),
  CONSTRAINT fk_service_setup_version_service_setup_id FOREIGN KEY (service_setup_id) REFERENCES service_setup (id)
)
--rollback DROP TABLE public.service_setup_version
