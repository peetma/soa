--liquibase formatted sql

--changeset siimveskilt:add_service_setup_version_localization_data_prod context:prod
insert into service_setup_version_localization(service_setup_version_id, language, general, steps)
values (1, 'et',
        '{
            "name": "Abiellumine",
            "description": "Abiellumise sündmusteenus sisaldab kasutaja vaates abiellumise protsessi alates abiellumise avalduse esitamisest kuni isikut tõendavate dokumentide uuendamiseni.",
            "mobileHelpText": "Siit leiate info Eestis abiellumise kohta – kus saab abielu sõlmida, kuidas esitada avaldust, millised on varasuhte valikud ning perekonnanime muutmise tingimused jm",
            "keywords": "Abielu registreerimine, Abielu sõlmimine, Abiellumine, Abiellumine Tartus, Abiellumine Tallinnas, Abiellumise riigilõiv, Abiellumine välismaal, Abiellumine Eestis, Abieluvara leping, Varalahusus, Ühisvara, Kiriklik laulatus, Abiellumine kirikus, Abielu sõlmimine notari juures, Abieluavalduse esitamine, Kus saan abielluda, Perekonnanime muutmine, Kas abiellumisel muutub perekonnanimi, Kui palju maksab abiellumine, Kas abielluda saab mõisas, Kas abielluda saab talus, Perekonnaseisusutus, Abieluvõimetõend, Abielutõend, Elektrooniline abiellumisavaldus, Abielu e-avaldus, e-rahvastikuregister, Kohtu luba abiellumiseks, Millal on abielu sõlmitud, Jah-sõna ütlemine, Kui kiiresti saab abielluda"
         }',
        '[
            {
               "title": "Avalduse esitamine",
               "relativeUrl": "/avalduse-esitamine",
               "mainArticleId": 39,
               "contentArticlesTitle": "Oluline teada selles sammus",
               "contentArticleIds": [35, 40, 42, 37, 34, 33, 36, 38, 41, 43],
               "referenceArticlesTitle": "Viited",
               "referenceArticleIds": [18, 20, 19],
               "contactArticleId": 31,
               "actionsTitle": "Iseteenindus",
               "actions": [
                 {
                   "infoBoxTitle": "Abiellumisavaldus",
                   "infoBoxDescription": "Esitage avaldus e-rahvastikuregistris",
                   "buttonText": "Avaldust esitama",
                   "url": "https://kodanikuportaal-test.cloud.smit.test/family/marriage-registration",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/et/abiellumine/avalduse-esitamine",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "Aja ja koha kinnitus",
               "relativeUrl": "/aja-ja-koha-kinnitus",
               "mainArticleId": 14,
               "contentArticlesTitle": "Oluline teada selles sammus",
               "contentArticleIds": [12, 13, 17, 15, 16],
               "referenceArticlesTitle": "Viited",
               "referenceArticleIds": [18, 20, 19],
               "contactArticleId": 31,
               "actionsTitle": "Iseteenindus",
               "actions": [],
               "notifications": [
                  {
                     "level": "INFO",
                     "text": "Selles sammus Te ise midagi tegema ei pea. Kohalik omavalitsus võtab Teiega ühendust, kui abielu sõlmimise aeg ja koht vajavad kinnitamist."
                  }
               ]
            },
            {
               "title": "Abielu registreerimine",
               "relativeUrl": "/abielu-registreerimine",
               "mainArticleId": 22,
               "contentArticlesTitle": "Oluline teada selles sammus",
               "contentArticleIds": [23, 21],
               "referenceArticlesTitle": "Viited",
               "referenceArticleIds": [18, 20, 19],
               "contactArticleId": 31,
               "actionsTitle": "Iseteenindus",
               "actions": [],
               "notifications": []
            },
            {
               "title": "ID-kaardi ja passi taotlemine",
               "relativeUrl": "/id-kaardi-ja-passi-taotlemine",
               "mainArticleId": 25,
               "contentArticlesTitle": "Oluline teada selles sammus",
               "contentArticleIds": [26, 24, 28, 27],
               "referenceArticlesTitle": "Viited",
               "referenceArticleIds": [18, 20, 19],
               "contactArticleId": 31,
               "actionsTitle": "Iseteenindus",
               "actions": [
                 {
                   "infoBoxTitle": "Isikut tõendavate dokumentide taotlus",
                   "infoBoxDescription": "Esitage avaldus Politsei- ja Piirivalveametile",
                   "buttonText": "Avaldust esitama",
                   "url": "https://www.politsei.ee/et/juhend/id-kaardi-taotlemine-taeiskasvanule",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/et/abiellumine/id-kaardi-ja-passi-taotlemine",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_documents_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "ID-kaardi ja passi kättesaamine",
               "relativeUrl": "/id-kaardi-ja-passi-kattesaamine",
               "mainArticleId": 30,
               "contentArticlesTitle": "Oluline teada selles sammus",
               "contentArticleIds": [29],
               "referenceArticlesTitle": "Viited",
               "referenceArticleIds": [18, 20, 19],
               "contactArticleId": 31,
               "actionsTitle": "Iseteenindus",
               "actions": [
                 {
                   "infoBoxTitle": "Dokumendi valmimine",
                   "infoBoxDescription": "Kontrollige, millal dokument valmis saab",
                   "buttonText": "Kontrollima",
                   "url": "https://www.politsei.ee/et/paringud/eesti-kodaniku-dokumendi-taotluse-staatus",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/et/abiellumine/id-kaardi-ja-passi-kattesaamine",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_checking_status.svg"
                 },
                 {
                   "infoBoxTitle": "Aja broneerimine",
                   "infoBoxDescription": "Broneerige aeg dokumentide kättesaamiseks",
                   "buttonText": "Aega broneerima",
                   "url": "https://broneering.politsei.ee/",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/et/abiellumine/id-kaardi-ja-passi-kattesaamine",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_booking_an_appointment.svg"
                 }
               ],
               "notifications": []
            }
         ]'),
       (1, 'en',
        '{
            "name": "Getting married",
            "description": "Here you can find information about getting married in Estonia - who concludes marriages, how to submit an application, how quickly you can get married, what are the property relationship options and the conditions for changing your surname, etc.",
            "mobileHelpText": "Here you can find information about getting married in Estonia - who concludes marriages, how to submit an application, how quickly you can get married, what are the property relationship options and the conditions for changing your surname, etc.",
            "keywords": "Marriage registration, Marriage contraction, Marriage, Marriage in Tartu, Marriage in Tallinn, State fee for marriage, Marriage abroad, Marriage in Estonia, Marital property contract, Separation of property, Joint property, Church wedding, Marriage at church, Marriage contraction at notary, Submitting marriage application, Where can I marry, Changing surname, Does surname change when getting married, How much does getting married cost, Can you marry in manor, Can you marry in farm, Vital statistics office, Certificate of legal capacity to contract marriage, Marriage certificate, Electronic marriage application, E-application of marriage, e-population register, Court permission to get married, When has the marriage been contracted, Saying yes, How quickly can you marry"
         }',
        '[
            {
               "title": "Submission of application",
               "relativeUrl": "/submission-of-application",
               "mainArticleId": 72,
               "contentArticlesTitle": "Important to know concerning this step",
               "contentArticleIds": [68, 73, 75, 70, 67, 66, 69, 71, 74, 76],
               "referenceArticlesTitle": "References",
               "referenceArticleIds": [51, 53, 52],
               "contactArticleId": 64,
               "actionsTitle": "Self-service",
               "actions": [
                 {
                   "infoBoxTitle": "Marriage application",
                   "infoBoxDescription": "Submit an application in the e-population register",
                   "buttonText": "Submit an application",
                   "url": "https://kodanikuportaal-test.cloud.smit.test/family/marriage-registration",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/en/getting-married/submission-of-application",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "Confirmation of time and place",
               "relativeUrl": "/confirmation-of-time-and-place",
               "mainArticleId": 47,
               "contentArticlesTitle": "Important to know concerning this step",
               "contentArticleIds": [45, 46, 50, 48, 49],
               "referenceArticlesTitle": "References",
               "referenceArticleIds": [51, 53, 52],
               "contactArticleId": 64,
               "actionsTitle": "Self-service",
               "actions": [],
               "notifications": [
                  {
                     "level": "INFO",
                     "text": "You don’t have to do anything yourself in this step. The local government will contact you if the time and place of the marriage needs to be confirmed."
                  }
               ]
            },
            {
               "title": "Getting married",
               "relativeUrl": "/getting-married",
               "mainArticleId": 55,
               "contentArticlesTitle": "Important to know concerning this step",
               "contentArticleIds": [56, 54],
               "referenceArticlesTitle": "References",
               "referenceArticleIds": [51, 53, 52],
               "contactArticleId": 64,
               "actionsTitle": "Self-service",
               "actions": [],
               "notifications": []
            },
            {
               "title": "Application for ID-card and passport",
               "relativeUrl": "/application-for-id-card-and-passport",
               "mainArticleId": 58,
               "contentArticlesTitle": "Important to know concerning this step",
               "contentArticleIds": [59, 57, 61, 60],
               "referenceArticlesTitle": "References",
               "referenceArticleIds": [51, 53, 52],
               "contactArticleId": 65,
               "actionsTitle": "Self-service",
               "actions": [
                 {
                   "infoBoxTitle": "Request for identity documents",
                   "infoBoxDescription": "Submit an application to the Police and Border Guard Board",
                   "buttonText": "Submit an application",
                   "url": "https://www.politsei.ee/et/juhend/id-kaardi-taotlemine-taeiskasvanule",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/en/getting-married/application-for-id-card-and-passport",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_documents_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "Receiving the ID-card and passport",
               "relativeUrl": "/receiving-the-id-card-and-passport",
               "mainArticleId": 63,
               "contentArticlesTitle": "Important to know concerning this step",
               "contentArticleIds": [62],
               "referenceArticlesTitle": "References",
               "referenceArticleIds": [51, 53, 52],
               "contactArticleId": 65,
               "actionsTitle": "Self-service",
               "actions": [
                 {
                   "infoBoxTitle": "Completion of the document",
                   "infoBoxDescription": "Check when the document will be ready",
                   "buttonText": "Check",
                   "url": "https://www.politsei.ee/en/inquiries/estonian-citizen-s-document-application-status",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/en/getting-married/receiving-the-id-card-and-passport",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_checking_status.svg"
                 },
                 {
                   "infoBoxTitle": "Booking an appointment",
                   "infoBoxDescription": "Book an appointment at the Police and Border Guard Board service",
                   "buttonText": "Book an appointment",
                   "url": "https://broneering.politsei.ee/",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/en/getting-married/receiving-the-id-card-and-passport",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_booking_an_appointment.svg"
                 }
               ],
               "notifications": []
            }
         ]'),
       (1, 'ru',
        '{
            "name": "Заключение брака",
            "description": "Здесь Вы найдете информацию о заключении брака в Эстонии – кто заключает брак, как подать заявление, как быстро можно заключить брак, какие варианты имущественного отношения существуют, условия смены фамилии и т. д",
            "mobileHelpText": "Здесь Вы найдете информацию о заключении брака в Эстонии – кто заключает брак, как подать заявление, как быстро можно заключить брак, какие варианты имущественного отношения существуют, условия смены фамилии и т. д",
            "keywords": "Регистрация брака, Заключение брака, Вступление в брак, Вступление в брак в Тарту, Вступление в брак в Таллинне, Госпошлина за заключение брака, Вступление в брак за рубежом, Вступление в брак в Эстонии, Брачный контракт, Раздельность имущества, Совместное имущество, Венчание в церкви, Бракосочетание в церкви, Заключение брака у нотариуса, Подача заявления о вступлении в брак, Где можно вступить в брак, Изменение фамилии, Изменяются ли фамилия при вступлении в брак, Сколько стоит вступление в брак, Можно ли вступить в брак на мызе, Можно ли вступить в брак на хуторе, Учреждение записи актов гражданского состояния, Справка о способности к вступлению в брак, Справка о заключении брака, Электронное заявление о вступлении в брак, Электронное заявление о вступлении в брак, Электронный регистр народонаселения, Разрешение суда на вступление в брак, Когда брак заключен, Произнесение слова «да», Как быстро можно вступить в брак"
         }',
        '[
            {
               "title": "Подача заявления",
               "relativeUrl": "/podaca-zaavlenia",
               "mainArticleId": 105,
               "contentArticlesTitle": "На этом этапе важно знать",
               "contentArticleIds": [101, 106, 108, 103, 100, 99, 102, 104, 107, 109],
               "referenceArticlesTitle": "Ссылки",
               "referenceArticleIds": [84, 86, 85],
               "contactArticleId": 97,
               "actionsTitle": "Самообслуживание",
               "actions": [
                 {
                   "infoBoxTitle": "Заявление о заключении брака",
                   "infoBoxDescription": "Подайте заявление в электронном регистре народонаселения",
                   "buttonText": "Подать заявление",
                   "url": "https://kodanikuportaal-test.cloud.smit.test/family/marriage-registration",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/ru/zaključenie-braka/podača-zajavlenija",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "Подтверждение времени и места",
               "relativeUrl": "/podtverzdenie-vremeni-i-mesta",
               "mainArticleId": 80,
               "contentArticlesTitle": "На этом этапе важно знать",
               "contentArticleIds": [78, 79, 83, 81, 82],
               "referenceArticlesTitle": "Ссылки",
               "referenceArticleIds": [84, 86, 85],
               "contactArticleId": 97,
               "actionsTitle": "Самообслуживание",
               "actions": [],
               "notifications": [
                  {
                     "level": "INFO",
                     "text": "На этом шаге Вам не нужно ничего делать. Местное самоуправление свяжется с Вами, если необходимо будет подтвердить время и место заключения брака."
                  }
               ]
            },
            {
               "title": "Регистрация брака",
               "relativeUrl": "/registracia-braka",
               "mainArticleId": 106,
               "contentArticlesTitle": "На этом этапе важно знать",
               "contentArticleIds": [107, 105],
               "referenceArticlesTitle": "Ссылки",
               "referenceArticleIds": [102, 104, 103],
               "contactArticleId": 115,
               "actionsTitle": "Самообслуживание",
               "actions": [],
               "notifications": []
            },
            {
               "title": "Подача заявления на получение ID-карты и паспорта",
               "relativeUrl": "/podaca-zaavlenia-na-polucenie-id-karty-i-pasporta",
               "mainArticleId": 91,
               "contentArticlesTitle": "На этом этапе важно знать",
               "contentArticleIds": [92, 90, 94, 93],
               "referenceArticlesTitle": "Ссылки",
               "referenceArticleIds": [84, 86, 85],
               "contactArticleId": 98,
               "actionsTitle": "Самообслуживание",
               "actions": [
                 {
                   "infoBoxTitle": "Ходатайство на получение документов, удостоверяющих личность",
                   "infoBoxDescription": "Подайте заявление в Департамент полиции и погранохраны",
                   "buttonText": "Подать заявление",
                   "url": "https://www.politsei.ee/ru/instruktsii/hodataystvo-o-vydache-id-karty-vzroslomu",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/ru/zaključenie-braka/podača-zajavlenija-na-polučenie-id-karty-i-pasporta",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_documents_application.svg"
                 }
               ],
               "notifications": []
            },
            {
               "title": "Получение ID-карты и паспорта",
               "relativeUrl": "/polucenie-id-karty-i-pasporta",
               "mainArticleId": 96,
               "contentArticlesTitle": "На этом этапе важно знать",
               "contentArticleIds": [95],
               "referenceArticlesTitle": "Ссылки",
               "referenceArticleIds": [84, 86, 85],
               "contactArticleId": 98,
               "actionsTitle": "Самообслуживание",
               "actions": [
                 {
                   "infoBoxTitle": "Документ готов",
                   "infoBoxDescription": "Проверьте, когда документ будет готов",
                   "buttonText": "Проверить",
                   "url": "https://www.politsei.ee/ru/zaprosy/status-zayavleniya-grazhdanina-estonii",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/ru/zaključenie-braka/polučenie-id-karty-i-pasporta",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_checking_status.svg"
                 },
                 {
                   "infoBoxTitle": "Бронирование времени",
                   "infoBoxDescription": "Забронируйте время в бюро обслуживания Департамента полиции и погранохраны",
                   "buttonText": "Забронировать время",
                   "url": "https://broneering.politsei.ee/",
                   "returnUrl": "https://test.eesti.ee/syndmusteenused/ru/zaključenie-braka/polučenie-id-karty-i-pasporta",
                   "returnUrlCode": "eventServices.marriage",
                   "imageName": "marriage_booking_an_appointment.svg"
                 }
               ],
               "notifications": []
            }
         ]');
--rollback DELETE FROM service_setup_version_localization
