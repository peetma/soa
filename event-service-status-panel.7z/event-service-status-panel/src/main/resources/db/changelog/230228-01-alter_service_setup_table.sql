--liquibase formatted sql

--changeset sarah:add_column_service_code_to_service_setup
ALTER TABLE service_setup ADD COLUMN service_code text;

CREATE UNIQUE INDEX key_service_setup_code ON service_setup(service_code);
--rollback ALTER TABLE public.service_setup DROP COLUMN service_code
