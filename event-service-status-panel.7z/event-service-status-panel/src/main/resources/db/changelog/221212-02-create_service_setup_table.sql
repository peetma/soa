--liquibase formatted sql

--changeset sarah:alter_service_setup_table
drop table if exists service_setup;
create table service_setup
(
    id             serial    CONSTRAINT pk_service_setup PRIMARY KEY,
    relative_urls  jsonb     NOT NULL,
    created        timestamp NOT NULL DEFAULT current_timestamp,
    created_by     text      NOT NULL DEFAULT 'SYSTEM',
    modified       timestamp NOT NULL DEFAULT current_timestamp,
    modified_by    text      NOT NULL DEFAULT 'SYSTEM'
)
--rollback DROP TABLE public.service_setup
