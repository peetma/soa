--liquibase formatted sql

--changeset sarah:create_service_setup_version_localization_table
create table if not exists service_setup_version_localization
(
  id                       serial     CONSTRAINT pk_service_setup_version_localization PRIMARY KEY,
  service_setup_version_id integer    NOT NULL,
  language                 varchar(2) NOT NULL,
  general                  jsonb      NOT NULL,
  steps                    jsonb      NOT NULL,
  created                  timestamp  NOT NULL DEFAULT current_timestamp,
  created_by               text       NOT NULL DEFAULT 'SYSTEM',
  modified                 timestamp  NOT NULL DEFAULT current_timestamp,
  modified_by              text       NOT NULL DEFAULT 'SYSTEM',
  CONSTRAINT key_service_setup_version_localization_service_setup_version_id_language UNIQUE(service_setup_version_id, language),
  CONSTRAINT fk_service_setup_version_localization_service_setup_version_id FOREIGN KEY (service_setup_version_id) REFERENCES service_setup_version (id)
)
--rollback DROP TABLE public.service_setup_version_localization
