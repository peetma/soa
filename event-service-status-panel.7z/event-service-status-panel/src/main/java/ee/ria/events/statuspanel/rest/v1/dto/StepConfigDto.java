package ee.ria.events.statuspanel.rest.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class StepConfigDto {
  String title;
  @JsonProperty(access = JsonProperty.Access.READ_ONLY)
  String relativeUrl;
  Integer mainArticleId;
  String contentArticlesTitle;
  List<Integer> contentArticleIds;
  String referenceArticlesTitle;
  List<Integer> referenceArticleIds;
  Integer contactArticleId;
  String actionsTitle;
  List<ActionDto> actions;
  List<NotificationDto> notifications;
}
