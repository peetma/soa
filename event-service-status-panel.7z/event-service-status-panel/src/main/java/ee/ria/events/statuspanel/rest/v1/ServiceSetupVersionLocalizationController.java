package ee.ria.events.statuspanel.rest.v1;

import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.usecase.GetServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionLocalizationDto;
import ee.ria.events.statuspanel.rest.v1.mapper.ServiceSetupVersionLocalizationDtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@RequestMapping("/internal/v1/services/setup/{language}/versions/{versionId}")
public class ServiceSetupVersionLocalizationController {

  private final ServiceSetupVersionLocalizationDtoMapper mapper;
  private final GetServiceSetupVersionLocalization getServiceSetupVersionLocalization;

  @GetMapping
  @Operation(summary = "Get localized service setup version")
  @ApiResponse(responseCode = "200", description = "Success")
  @ApiResponse(responseCode = "404", description = "Service setup version is not found or is deleted",
      content = @Content(schema = @Schema()))
  public Mono<ServiceSetupVersionLocalizationDto> getLocalizedVersion(
      @PathVariable String language,
      @PathVariable Integer versionId
  ) {
    return getServiceSetupVersionLocalization.execute(versionId, Language.fromString(language))
        .map(mapper::toDto);
  }

}
