package ee.ria.events.statuspanel.rest.v1.dto;

public enum NotificationLevelDto {
  LOW_PRIORITY, INFO, WARNING, ERROR, SUCCESS
}
