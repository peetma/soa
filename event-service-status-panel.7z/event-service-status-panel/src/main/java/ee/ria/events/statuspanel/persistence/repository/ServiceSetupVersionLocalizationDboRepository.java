package ee.ria.events.statuspanel.persistence.repository;

import ee.ria.events.statuspanel.persistence.entity.ServiceNameDbo;
import ee.ria.events.statuspanel.persistence.entity.ServiceSetupVersionLocalizationDbo;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
public interface ServiceSetupVersionLocalizationDboRepository extends ReactiveCrudRepository<ServiceSetupVersionLocalizationDbo, Integer> {

  Mono<ServiceSetupVersionLocalizationDbo> findByServiceSetupVersionIdAndLanguageIgnoreCase(
      Integer serviceSetupVersionId, String language
  );

  Flux<ServiceSetupVersionLocalizationDbo> findByServiceSetupVersionId(Integer serviceSetupVersionId);

  @Query("SELECT service_setup_version_id, general->>'name' \"name\" FROM service_setup_version_localization " +
      "WHERE service_setup_version_id IN (:serviceSetupVersionIds) AND UPPER(language) = UPPER(:language)")
  Flux<ServiceNameDbo> findNameByServiceSetupVersionIdsAndLanguage(List<Integer> serviceSetupVersionIds, String language);

}
