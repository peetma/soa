package ee.ria.events.statuspanel.rest.v1.dto;

import lombok.Builder;
import lombok.Value;

import java.util.Map;

@Value
@Builder
public class ServiceSetupVersionRouteDto {
  Integer serviceSetupId;
  Integer serviceSetupVersionId;
  Map<String, String> relativeUrls;
}
