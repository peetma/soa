package ee.ria.events.statuspanel.core.service.port.persistence;

import ee.ria.events.statuspanel.core.model.ServiceSetup;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ServiceSetupPersistencePort {

  Mono<ServiceSetup> getById(Integer id);

  Mono<ServiceSetup> getByCode(String serviceCode);

  Flux<ServiceSetup> getAll();

  Mono<ServiceSetup> save(ServiceSetup setup);

}
