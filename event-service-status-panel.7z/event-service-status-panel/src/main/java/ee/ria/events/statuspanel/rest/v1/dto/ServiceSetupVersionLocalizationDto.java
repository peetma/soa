package ee.ria.events.statuspanel.rest.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class ServiceSetupVersionLocalizationDto {
  Integer id;
  @JsonProperty(access = JsonProperty.Access.READ_ONLY)
  Integer serviceSetupVersionId;
  String language;
  GeneralConfigDto general;
  List<StepConfigDto> steps;
}
