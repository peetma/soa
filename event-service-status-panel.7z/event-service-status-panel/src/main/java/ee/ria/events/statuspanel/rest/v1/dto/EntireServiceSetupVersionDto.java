package ee.ria.events.statuspanel.rest.v1.dto;

import lombok.Builder;
import lombok.Value;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Value
@Builder
public class EntireServiceSetupVersionDto {
  Integer id;
  Integer serviceSetupId;
  String serviceCode;
  LocalDate startDate;
  ServiceSetupVersionStatusDto status;
  OwnerDto owner;
  Map<String, String> relativeUrls;
  List<ServiceSetupVersionLocalizationDto> localizations;
}
