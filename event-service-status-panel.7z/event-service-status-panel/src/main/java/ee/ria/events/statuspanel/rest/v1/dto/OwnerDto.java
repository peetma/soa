package ee.ria.events.statuspanel.rest.v1.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class OwnerDto {
  String registerCode;
  String name;
  String contactPersonName;
  String email;
  String phoneNumber;
}
