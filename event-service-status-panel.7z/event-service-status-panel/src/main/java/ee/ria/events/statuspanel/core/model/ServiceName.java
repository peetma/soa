package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ServiceName {
  Integer serviceSetupVersionId;
  String name;
}
