package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.time.Instant;
import java.time.LocalDate;

@Value
@Builder(toBuilder = true)
public class ServiceSetupVersion {
  Integer id;
  Integer serviceSetupId;
  LocalDate startDate;
  Owner owner;
  Instant created;
  String createdBy;
  Instant modified;
  boolean deleted;
}
