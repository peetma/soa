package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.model.GeneralConfig;
import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.Owner;
import ee.ria.events.statuspanel.core.model.ServiceSetup;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.EnumSet;
import java.util.List;

@Component
@RequiredArgsConstructor
public class CreateServiceSetupVersion {

  private final ServiceSetupPersistencePort setupPort;
  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  @Transactional
  public Mono<Integer> execute() {
    return setupPort.save(ServiceSetup.builder().build())
        .flatMap(setup -> versionPort.save(createVersion(setup)))
        .flatMapMany(version -> localizationPort.save(createLocalizations(version)))
        .last()
        .map(ServiceSetupVersionLocalization::getServiceSetupVersionId);
  }

  private static ServiceSetupVersion createVersion(ServiceSetup setup) {
    return ServiceSetupVersion.builder()
        .serviceSetupId(setup.getId())
        .owner(Owner.builder().build())
        .build();
  }

  private static List<ServiceSetupVersionLocalization> createLocalizations(ServiceSetupVersion version) {
    return EnumSet.allOf(Language.class).stream()
        .map(lang -> ServiceSetupVersionLocalization.builder()
            .serviceSetupVersionId(version.getId())
            .language(lang)
            .general(GeneralConfig.builder().build())
            .build())
        .toList();
  }

}
