package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Value
@Builder
public class EntireServiceSetupVersion {
  Integer id;
  Integer serviceSetupId;
  String serviceCode;
  LocalDate startDate;
  ServiceSetupVersionStatus status;
  Owner owner;
  Map<String, String> relativeUrls;
  List<ServiceSetupVersionLocalization> localizations;
}
