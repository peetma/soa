package ee.ria.events.statuspanel.persistence.mapper;

import ee.ria.events.statuspanel.core.model.GeneralConfig;
import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.model.StepConfig;
import ee.ria.events.statuspanel.persistence.entity.ServiceSetupVersionLocalizationDbo;
import io.r2dbc.postgresql.codec.Json;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

import static java.util.Arrays.asList;

@Mapper(componentModel = "spring")
public interface ServiceSetupVersionLocalizationDboMapper
    extends BaseDboMapper<ServiceSetupVersionLocalizationDbo, ServiceSetupVersionLocalization> {

  @Override
  @Mapping(source = "general", target = "general", qualifiedByName = "jsonToGeneralConfig")
  @Mapping(source = "steps", target = "steps", qualifiedByName = "jsonToStepConfigs")
  @Mapping(source = "language", target = "language", qualifiedByName = "stringToLanguage")
  ServiceSetupVersionLocalization toModel(ServiceSetupVersionLocalizationDbo entity);

  @Override
  @Mapping(source = "general", target = "general", qualifiedByName = "objectToJson")
  @Mapping(source = "steps", target = "steps", qualifiedByName = "listToJson")
  @Mapping(source = "language", target = "language", qualifiedByName = "languageToString")
  ServiceSetupVersionLocalizationDbo toDbo(ServiceSetupVersionLocalization model);

  @Named("jsonToGeneralConfig")
  default GeneralConfig jsonToGeneralConfig(Json generalConfig) {
    return JsonMapper.getObject(generalConfig, GeneralConfig.class);
  }

  @Named("jsonToStepConfigs")
  default List<StepConfig> jsonToStepConfigs(Json stepConfigs) {
    return asList(JsonMapper.getObject(stepConfigs, StepConfig[].class));
  }

  @Named("languageToString")
  default String languageToString(Language language) {
    return language.name().toLowerCase();
  }

  @Named("stringToLanguage")
  default Language stringToLanguage(String language) {
    return Language.fromString(language);
  }
}
