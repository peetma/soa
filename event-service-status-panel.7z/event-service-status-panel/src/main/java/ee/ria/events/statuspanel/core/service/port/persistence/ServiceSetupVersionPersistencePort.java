package ee.ria.events.statuspanel.core.service.port.persistence;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

public interface ServiceSetupVersionPersistencePort {

  Mono<ServiceSetupVersion> getById(Integer id);

  Mono<ServiceSetupVersion> getActiveOn(Integer serviceSetupId, LocalDate date);

  Flux<ServiceSetupVersion> getAllActive();

  Flux<ServiceSetupVersion> getAllNonDeleted();

  Mono<ServiceSetupVersion> save(ServiceSetupVersion version);

}
