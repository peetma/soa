package ee.ria.events.statuspanel.rest.v1.context;

import lombok.Value;

@Value
public class UserContext {
  String personalCode;
}
