package ee.ria.events.statuspanel.core.model;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ErrorCode {
  public static final String NO_PREVIOUS_VERSION_FOUND = "events.status-panel.version.not-found";
}
