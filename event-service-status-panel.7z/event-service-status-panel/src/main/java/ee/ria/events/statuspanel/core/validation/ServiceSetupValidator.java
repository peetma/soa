package ee.ria.events.statuspanel.core.validation;

import ee.ria.events.statuspanel.core.model.ServiceSetup;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import static ee.ria.events.statuspanel.core.model.ErrorCode.NO_PREVIOUS_VERSION_FOUND;

@Component
public class ServiceSetupValidator extends AbstractValidator<ServiceSetupValidator.ServiceSetupValidatorCommand> {

  public ServiceSetupValidator() {
    super(ServiceSetupValidator.ServiceSetupValidatorCommand.class);
  }

  @Override
  protected void validateTarget(ServiceSetupValidatorCommand target, Errors errors) {
    // TODO add more validations
    versionExistsIfUpdating(target, errors);
  }

  private void versionExistsIfUpdating(ServiceSetupValidatorCommand command, Errors errors) {
    if (command.lastVersion == null && !command.createNewVersion) {
      errors.rejectValue(null, NO_PREVIOUS_VERSION_FOUND);
    }
  }

  @Data
  @AllArgsConstructor
  public static class ServiceSetupValidatorCommand {
    private ServiceSetup input;
    private ServiceSetup lastVersion;
    private boolean createNewVersion;
  }
}
