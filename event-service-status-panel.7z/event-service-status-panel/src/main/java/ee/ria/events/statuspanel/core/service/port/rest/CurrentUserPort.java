package ee.ria.events.statuspanel.core.service.port.rest;

import reactor.core.publisher.Mono;

public interface CurrentUserPort {

  Mono<String> getPersonalCode();

}
