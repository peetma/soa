package ee.ria.events.statuspanel.persistence;

import ee.ria.events.statuspanel.core.model.ServiceSetup;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupPersistencePort;
import ee.ria.events.statuspanel.persistence.mapper.ServiceSetupDboMapper;
import ee.ria.events.statuspanel.persistence.repository.ServiceSetupDboRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
@RequiredArgsConstructor
public class ServiceSetupPersistenceAdapter implements ServiceSetupPersistencePort {

  private final ServiceSetupDboRepository repository;
  private final ServiceSetupDboMapper mapper;

  @Override
  public Mono<ServiceSetup> getById(Integer id) {
    return repository.findById(id)
        .map(mapper::toModel);
  }

  @Override
  public Mono<ServiceSetup> getByCode(String serviceCode) {
    return repository.findByServiceCode(serviceCode)
        .map(mapper::toModel);
  }

  @Override
  public Flux<ServiceSetup> getAll() {
    return repository.findAll()
        .map(mapper::toModel);
  }

  @Override
  public Mono<ServiceSetup> save(ServiceSetup setup) {
    return repository.save(mapper.toDbo(setup))
        .map(mapper::toModel);
  }

}
