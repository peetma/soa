package ee.ria.events.statuspanel.rest.v1.context;

import ee.ria.events.statuspanel.core.service.port.rest.CurrentUserPort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class CurrentUserService implements CurrentUserPort {

  @Override
  public Mono<String> getPersonalCode() {
    return UserContextHolder.getContext()
        .map(UserContext::getPersonalCode);
  }

}
