package ee.ria.events.statuspanel.persistence.mapper;

import ee.ria.events.statuspanel.core.model.ServiceName;
import ee.ria.events.statuspanel.persistence.entity.ServiceNameDbo;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ServiceNameDboMapper extends BaseDboMapper<ServiceNameDbo, ServiceName> {
}
