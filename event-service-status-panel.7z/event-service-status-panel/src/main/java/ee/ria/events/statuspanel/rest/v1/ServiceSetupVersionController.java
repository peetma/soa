package ee.ria.events.statuspanel.rest.v1;

import ee.ria.events.statuspanel.core.usecase.CreateServiceSetupVersion;
import ee.ria.events.statuspanel.core.usecase.DeleteServiceSetupVersion;
import ee.ria.events.statuspanel.core.usecase.GetActiveServiceSetupVersionRoutes;
import ee.ria.events.statuspanel.core.usecase.GetServiceSetupVersion;
import ee.ria.events.statuspanel.core.usecase.GetServiceSetupVersionList;
import ee.ria.events.statuspanel.core.usecase.UpdateServiceSetupVersion;
import ee.ria.events.statuspanel.rest.v1.dto.EntireServiceSetupVersionDto;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionForSavingDto;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionListItemDto;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionRouteDto;
import ee.ria.events.statuspanel.rest.v1.mapper.EntireServiceSetupVersionDtoMapper;
import ee.ria.events.statuspanel.rest.v1.mapper.ServiceSetupVersionForSavingDtoMapper;
import ee.ria.events.statuspanel.rest.v1.mapper.ServiceSetupVersionListItemDtoMapper;
import ee.ria.events.statuspanel.rest.v1.mapper.ServiceSetupVersionRouteDtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@RequestMapping("/internal/v1/services/setup/versions")
public class ServiceSetupVersionController {

  private final ServiceSetupVersionListItemDtoMapper listMapper;
  private final GetServiceSetupVersionList getServiceSetupVersionList;
  private final ServiceSetupVersionRouteDtoMapper routesMapper;
  private final GetActiveServiceSetupVersionRoutes getActiveServiceSetupVersionRoutes;
  private final EntireServiceSetupVersionDtoMapper versionMapper;
  private final GetServiceSetupVersion getServiceSetupVersion;
  private final CreateServiceSetupVersion createServiceSetupVersion;
  private final ServiceSetupVersionForSavingDtoMapper versionForSavingMapper;
  private final UpdateServiceSetupVersion updateServiceSetupVersion;
  private final DeleteServiceSetupVersion deleteServiceSetupVersion;

  @GetMapping
  @Operation(summary = "Get all service setup versions",
      description = "Sorted by modified desc. Doesn't return deleted versions")
  @ApiResponse(responseCode = "200", description = "Success")
  public Flux<ServiceSetupVersionListItemDto> getAll() {
    return getServiceSetupVersionList.execute().map(listMapper::toDto);
  }

  @GetMapping("/routes")
  @Operation(summary = "Get route mappings for all currently active service setup versions")
  @ApiResponse(responseCode = "200", description = "Success")
  public Flux<ServiceSetupVersionRouteDto> getAllActiveVersionRoutes() {
    return getActiveServiceSetupVersionRoutes.execute().map(routesMapper::toDto);
  }

  @GetMapping("/{versionId}")
  @Operation(summary = "Get entire service setup version")
  @ApiResponse(responseCode = "200", description = "Success")
  @ApiResponse(responseCode = "404", description = "Service setup version is not found or is deleted",
      content = @Content(schema = @Schema()))
  public Mono<EntireServiceSetupVersionDto> get(@PathVariable Integer versionId) {
    return getServiceSetupVersion.execute(versionId).map(versionMapper::toDto);
  }

  @PostMapping
  @ResponseStatus(code = HttpStatus.CREATED)
  @Operation(summary = "Creates new service setup version",
      description = "Creates new service setup, service setup version and service setup version localization " +
          "for all supported languages")
  @ApiResponse(responseCode = "201", description = "Success. Returns id of created service setup version")
  public Mono<Integer> create() {
    return createServiceSetupVersion.execute();
  }

  @PutMapping("/{versionId}")
  @Operation(summary = "Save service setup version")
  @ApiResponse(responseCode = "200", description = "Success")
  @ApiResponse(responseCode = "403", description = "Service setup version is not editable",
      content = @Content(schema = @Schema()))
  @ApiResponse(responseCode = "404",
      description = "Service setup version or localization is not found or version is deleted",
      content = @Content(schema = @Schema()))
  public Mono<Integer> save(
      @PathVariable Integer versionId, @RequestBody ServiceSetupVersionForSavingDto version
  ) {
    return updateServiceSetupVersion.execute(versionId, versionForSavingMapper.toModel(version));
  }

  @DeleteMapping("/{versionId}")
  @ResponseStatus(code = HttpStatus.NO_CONTENT)
  @Operation(summary = "Delete service setup version (logically)")
  @ApiResponse(responseCode = "204", description = "Success")
  @ApiResponse(responseCode = "403", description = "Service setup version is not deletable",
      content = @Content(schema = @Schema()))
  @ApiResponse(responseCode = "404", description = "Service setup version is not found",
      content = @Content(schema = @Schema()))
  public Mono<Void> delete(@PathVariable Integer versionId) {
    return deleteServiceSetupVersion.execute(versionId);
  }

}
