package ee.ria.events.statuspanel.rest.v1.mapper;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersionRoute;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionRouteDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ServiceSetupVersionRouteDtoMapper
    extends BaseDtoMapper<ServiceSetupVersionRouteDto, ServiceSetupVersionRoute> {
}
