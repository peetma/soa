package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.model.EntireServiceSetupVersion;
import ee.ria.events.statuspanel.core.model.ServiceSetup;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionStatus;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Component
@RequiredArgsConstructor
public class GetActiveServiceSetupVersion {

  private final ServiceSetupPersistencePort setupPort;
  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  public Mono<EntireServiceSetupVersion> execute(String serviceCode, LocalDate activeOn) {
    return setupPort.getByCode(serviceCode)
        .zipWhen(setup -> versionPort.getActiveOn(setup.getId(), activeOn))
        .zipWhen(response -> localizationPort.getByVersionId(response.getT2().getId()).collectList())
        .map(response -> {
          ServiceSetup setup = response.getT1().getT1();
          ServiceSetupVersion version = response.getT1().getT2();
          List<ServiceSetupVersionLocalization> localizations = response.getT2().stream()
              .sorted(Comparator.comparing(ServiceSetupVersionLocalization::getLanguage)).toList();

          return EntireServiceSetupVersion.builder()
              .id(version.getId())
              .serviceSetupId(version.getServiceSetupId())
              .serviceCode(setup.getServiceCode())
              .startDate(version.getStartDate())
              .status(ServiceSetupVersionStatus.PUBLISHED)
              .owner(version.getOwner())
              .relativeUrls(setup.getRelativeUrls())
              .localizations(localizations)
              .build();
        }).switchIfEmpty(Mono.error(new ServiceSetupNotFoundException()));
  }

}
