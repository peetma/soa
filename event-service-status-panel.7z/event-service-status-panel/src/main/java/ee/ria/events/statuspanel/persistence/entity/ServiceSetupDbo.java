package ee.ria.events.statuspanel.persistence.entity;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("service_setup")
@EqualsAndHashCode(callSuper = true)
public class ServiceSetupDbo extends Auditable {

  @Id
  private Integer id;
  private String serviceCode;
  private Json relativeUrls;

}
