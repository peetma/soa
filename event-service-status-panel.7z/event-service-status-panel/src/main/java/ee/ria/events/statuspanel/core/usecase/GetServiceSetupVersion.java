package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.model.EntireServiceSetupVersion;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionStatus;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class GetServiceSetupVersion {

  private final Clock clock;
  private final ServiceSetupPersistencePort setupPort;
  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  public Mono<EntireServiceSetupVersion> execute(Integer serviceSetupVersionId) {
    return versionPort.getById(serviceSetupVersionId)
        .filter(version -> !version.isDeleted())
        .flatMap(
            version -> Mono.zip(
                setupPort.getById(version.getServiceSetupId()),
                localizationPort.getByVersionId(serviceSetupVersionId).collectList(),
                (setup, localizations) -> EntireServiceSetupVersion.builder()
                    .id(version.getId())
                    .serviceSetupId(version.getServiceSetupId())
                    .serviceCode(setup.getServiceCode())
                    .startDate(version.getStartDate())
                    .status(ServiceSetupVersionStatus.fromStartDate(LocalDate.now(clock), version.getStartDate()))
                    .owner(version.getOwner())
                    .relativeUrls(setup.getRelativeUrls())
                    .localizations(localizations)
                    .build()
            )
        ).switchIfEmpty(Mono.error(new ServiceSetupNotFoundException()));
  }

}
