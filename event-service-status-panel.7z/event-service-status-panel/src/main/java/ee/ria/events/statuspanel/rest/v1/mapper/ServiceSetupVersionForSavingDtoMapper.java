package ee.ria.events.statuspanel.rest.v1.mapper;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersionForSaving;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionForSavingDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = ServiceSetupVersionLocalizationDtoMapper.class)
public interface ServiceSetupVersionForSavingDtoMapper
    extends BaseDtoMapper<ServiceSetupVersionForSavingDto, ServiceSetupVersionForSaving> {
}
