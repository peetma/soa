package ee.ria.events.statuspanel.rest.v1.mapper;

import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionLocalizationDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface ServiceSetupVersionLocalizationDtoMapper
    extends BaseDtoMapper<ServiceSetupVersionLocalizationDto, ServiceSetupVersionLocalization> {

  @Override
  @Mapping(source = "language", target = "language", qualifiedByName = "languageToString")
  ServiceSetupVersionLocalizationDto toDto(ServiceSetupVersionLocalization model);

  @Override
  @Mapping(source = "language", target = "language", qualifiedByName = "stringToLanguage")
  ServiceSetupVersionLocalization toModel(ServiceSetupVersionLocalizationDto dto);

  @Named("languageToString")
  default String languageToString(Language language) {
    return language.name().toLowerCase();
  }

  @Named("stringToLanguage")
  default Language stringToLanguage(String language) {
    return Language.fromString(language);
  }

}
