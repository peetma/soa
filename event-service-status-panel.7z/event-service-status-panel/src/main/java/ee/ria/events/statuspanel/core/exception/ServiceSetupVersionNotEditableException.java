package ee.ria.events.statuspanel.core.exception;

public class ServiceSetupVersionNotEditableException extends RuntimeException {
}
