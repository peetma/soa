package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class GetServiceSetupVersionLocalization {

  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  public Mono<ServiceSetupVersionLocalization> execute(Integer serviceSetupVersionId, Language language) {
    return versionPort.getById(serviceSetupVersionId)
        .filter(version -> !version.isDeleted())
        .flatMap(version -> localizationPort.getByVersionIdAndLanguage(version.getId(), language))
        .switchIfEmpty(Mono.error(new ServiceSetupNotFoundException()));
  }

}
