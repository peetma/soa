package ee.ria.events.statuspanel.persistence.mapper;

import ee.ria.events.statuspanel.core.model.ServiceSetup;
import ee.ria.events.statuspanel.persistence.entity.ServiceSetupDbo;
import io.r2dbc.postgresql.codec.Json;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Map;

@Mapper(componentModel = "spring")
public interface ServiceSetupDboMapper extends BaseDboMapper<ServiceSetupDbo, ServiceSetup> {

  @Override
  @Mapping(source = "relativeUrls", target = "relativeUrls", qualifiedByName = "jsonToRelativeUrls")
  ServiceSetup toModel(ServiceSetupDbo entity);

  @Override
  @Mapping(source = "relativeUrls", target = "relativeUrls", qualifiedByName = "mapToJson")
  ServiceSetupDbo toDbo(ServiceSetup model);

  @Named("jsonToRelativeUrls")
  default Map<String, String> jsonToRelativeUrls(Json relativeUrls) {
    return JsonMapper.getObject(relativeUrls, Map.class);
  }
}
