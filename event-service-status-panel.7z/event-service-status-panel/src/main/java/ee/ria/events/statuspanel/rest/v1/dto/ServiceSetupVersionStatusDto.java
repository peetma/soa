package ee.ria.events.statuspanel.rest.v1.dto;

public enum ServiceSetupVersionStatusDto {
  DRAFT, PENDING_PUBLICATION, PUBLISHED
}
