package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.exception.ServiceSetupLocalizationNotFoundException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupVersionNotEditableException;
import ee.ria.events.statuspanel.core.model.Constants;
import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionForSaving;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionStatus;
import ee.ria.events.statuspanel.core.model.StepConfig;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static ee.ria.events.statuspanel.core.model.Constants.DEFAULT_TITLES;
import static ee.ria.events.statuspanel.core.model.Constants.Title.ACTIONS;
import static ee.ria.events.statuspanel.core.model.Constants.Title.CONTENT_ARTICLES;
import static ee.ria.events.statuspanel.core.model.Constants.Title.REFERENCE_ARTICLES;

@Component
@RequiredArgsConstructor
public class UpdateServiceSetupVersion {

  private final Clock clock;
  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  @Transactional
  public Mono<Integer> execute(Integer versionId, ServiceSetupVersionForSaving version) {
    return saveVersion(versionId, version)
        .flatMap(updatedVersion -> saveLocalizations(updatedVersion.getId(), version).last())
        .map(ServiceSetupVersionLocalization::getServiceSetupVersionId);
  }

  private Mono<ServiceSetupVersion> saveVersion(Integer versionId, ServiceSetupVersionForSaving version) {
    return versionPort.getById(versionId)
        .filter(existingVersion -> !existingVersion.isDeleted())
        .switchIfEmpty(Mono.error(ServiceSetupNotFoundException::new))
        .filter(this::editable)
        .switchIfEmpty(Mono.error(ServiceSetupVersionNotEditableException::new))
        .map(existingVersion -> existingVersion.toBuilder().owner(version.getOwner()).build())
        .flatMap(versionPort::save);
  }

  private Flux<ServiceSetupVersionLocalization> saveLocalizations(
      Integer versionId, ServiceSetupVersionForSaving version
  ) {
    return localizationPort.getByVersionId(versionId).collectMap(ServiceSetupVersionLocalization::getId)
        .map(existingLocalizations ->
            version.getLocalizations().stream()
                .map(localization -> Optional.ofNullable(existingLocalizations.get(localization.getId()))
                    .map(existingLocalization -> updateLocalization(localization, existingLocalization))
                    .orElseThrow(() -> new ServiceSetupLocalizationNotFoundException(versionId, localization.getId())))
                .toList())
        .onErrorResume(Mono::error)
        .flatMapMany(localizationPort::save);
  }

  private boolean editable(ServiceSetupVersion version) {
    return !version.isDeleted()
        && ServiceSetupVersionStatus.fromStartDate(LocalDate.now(clock), version.getStartDate()).editable();
  }

  private ServiceSetupVersionLocalization updateLocalization(
      ServiceSetupVersionLocalization localization, ServiceSetupVersionLocalization existingLocalization
  ) {
    return localization.toBuilder()
        .serviceSetupVersionId(existingLocalization.getServiceSetupVersionId())
        .steps(updateSteps(localization.getSteps(), localization.getLanguage()))
        .created(existingLocalization.getCreated())
        .createdBy(existingLocalization.getCreatedBy())
        .build();
  }

  private List<StepConfig> updateSteps(List<StepConfig> steps, Language language) {
    Map<Constants.Title, String> titles = DEFAULT_TITLES.get(language);
    return steps.stream().map(step -> step.toBuilder()
            .contentArticlesTitle(Optional.ofNullable(step.getContentArticlesTitle()).orElse(titles.get(CONTENT_ARTICLES)))
            .referenceArticlesTitle(Optional.ofNullable(step.getReferenceArticlesTitle()).orElse(titles.get(REFERENCE_ARTICLES)))
            .actionsTitle(Optional.ofNullable(step.getActionsTitle()).orElse(titles.get(ACTIONS)))
            .build())
        .toList();
  }

}
