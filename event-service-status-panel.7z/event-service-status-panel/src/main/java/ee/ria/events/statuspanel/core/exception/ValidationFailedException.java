package ee.ria.events.statuspanel.core.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.Errors;

@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ValidationFailedException extends RuntimeException {
  private final Errors errors;
}
