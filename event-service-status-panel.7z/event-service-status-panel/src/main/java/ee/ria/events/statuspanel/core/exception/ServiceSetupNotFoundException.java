package ee.ria.events.statuspanel.core.exception;

public class ServiceSetupNotFoundException extends RuntimeException {
}
