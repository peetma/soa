package ee.ria.events.statuspanel.rest.v1.mapper;

import ee.ria.events.statuspanel.core.model.EntireServiceSetupVersion;
import ee.ria.events.statuspanel.rest.v1.dto.EntireServiceSetupVersionDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = ServiceSetupVersionLocalizationDtoMapper.class)
public interface EntireServiceSetupVersionDtoMapper
    extends BaseDtoMapper<EntireServiceSetupVersionDto, EntireServiceSetupVersion> {
}
