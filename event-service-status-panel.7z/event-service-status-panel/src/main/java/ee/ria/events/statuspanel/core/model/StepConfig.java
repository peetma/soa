package ee.ria.events.statuspanel.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class StepConfig {
  private String title;
  private String relativeUrl;
  private Integer mainArticleId;
  private String contentArticlesTitle;
  private List<Integer> contentArticleIds;
  private String referenceArticlesTitle;
  private List<Integer> referenceArticleIds;
  private Integer contactArticleId;
  private String actionsTitle;
  private List<Action> actions;
  private List<Notification> notifications;
}
