package ee.ria.events.statuspanel.persistence.repository;

import ee.ria.events.statuspanel.persistence.entity.ServiceSetupVersionDbo;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

@Repository
public interface ServiceSetupVersionDboRepository extends ReactiveCrudRepository<ServiceSetupVersionDbo, Integer> {

  @Query("SELECT * FROM service_setup_version " +
      "WHERE service_setup_id = :serviceSetupId AND start_date <= :date " +
      "ORDER BY start_date DESC " +
      "LIMIT 1")
  Mono<ServiceSetupVersionDbo> findActiveOn(Integer serviceSetupId, LocalDate date);

  @Query("SELECT DISTINCT ON (service_setup_id) * FROM service_setup_version " +
      "WHERE start_date <= :date " +
      "ORDER BY service_setup_id, start_date DESC")
  Flux<ServiceSetupVersionDbo> findAllActive(LocalDate date);

  Flux<ServiceSetupVersionDbo> findByDeletedFalse();

}
