package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.time.Instant;
import java.time.LocalDate;

@Value
@Builder
public class ServiceSetupVersionListItem {
  Integer id;
  String serviceName;
  String ownerName;
  String contactPersonName;
  String contactPersonEmail;
  LocalDate startDate;
  ServiceSetupVersionStatus status;
  Instant modified;
  boolean editable;
  boolean deletable;
}
