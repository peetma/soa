package ee.ria.events.statuspanel.core.model;

import java.util.Map;

import static ee.ria.events.statuspanel.core.model.Constants.Title.ACTIONS;
import static ee.ria.events.statuspanel.core.model.Constants.Title.CONTENT_ARTICLES;
import static ee.ria.events.statuspanel.core.model.Constants.Title.REFERENCE_ARTICLES;
import static ee.ria.events.statuspanel.core.model.Language.EN;
import static ee.ria.events.statuspanel.core.model.Language.ET;
import static ee.ria.events.statuspanel.core.model.Language.RU;

public class Constants {
  public static final Map<Language, Map<Title, String>> DEFAULT_TITLES = Map.of(
      ET, Map.of(
          CONTENT_ARTICLES, "Oluline teada selles sammus",
          REFERENCE_ARTICLES, "Viited",
          ACTIONS, "Iseteenindus"
      ),
      EN, Map.of(
          CONTENT_ARTICLES, "Important to know concerning this step",
          REFERENCE_ARTICLES, "References",
          ACTIONS, "Self-service"
      ),
      RU, Map.of(
          CONTENT_ARTICLES, "На этом этапе важно знать",
          REFERENCE_ARTICLES, "Ссылки",
          ACTIONS, "Самообслуживание"
      )
  );

  public enum Title {
    CONTENT_ARTICLES, REFERENCE_ARTICLES, ACTIONS
  }
}
