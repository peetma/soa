package ee.ria.events.statuspanel.rest.v1.dto;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersionStatus;
import lombok.Builder;
import lombok.Value;

import java.time.Instant;
import java.time.LocalDate;

@Value
@Builder
public class ServiceSetupVersionListItemDto {
  Integer id;
  String serviceName;
  String ownerName;
  String contactPersonName;
  String contactPersonEmail;
  LocalDate startDate;
  ServiceSetupVersionStatus status;
  Instant modified;
  boolean editable;
  boolean deletable;
}
