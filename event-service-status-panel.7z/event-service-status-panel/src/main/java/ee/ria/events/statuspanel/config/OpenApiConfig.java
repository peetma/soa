package ee.ria.events.statuspanel.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.customizers.GlobalOpenApiCustomizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static ee.ria.events.statuspanel.rest.v1.context.UserContextFilter.PERSONAL_CODE_HEADER;

@Configuration
@RequiredArgsConstructor
public class OpenApiConfig {

  private final BuildProperties buildProperties;

  @Bean
  public OpenAPI openAPI(
      @Value("${openapi.title:Define property 'openapi.title'!}") String title,
      @Value("${openapi.description:Define property 'openapi.description'!}") String description
  ) {
    return new OpenAPI()
        .info(new Info()
            .title(title)
            .description(description)
            .version(buildProperties.getVersion())
        );
  }

  @Bean
  public GlobalOpenApiCustomizer openApiCustomizer() {
    return openApi -> openApi.getPaths().values().stream()
        .flatMap(pathItem -> pathItem.readOperationsMap().entrySet().stream())
        .forEach(operation -> {
          if (!PathItem.HttpMethod.GET.equals(operation.getKey())) {
            operation.getValue().addParametersItem(
                new HeaderParameter()
                    .name(PERSONAL_CODE_HEADER)
                    .schema(new StringSchema())
                    .required(true));
          }
        });
  }

}
