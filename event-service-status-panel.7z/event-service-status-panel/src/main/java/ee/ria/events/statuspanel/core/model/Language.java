package ee.ria.events.statuspanel.core.model;

import ee.ria.events.statuspanel.core.exception.UnsupportedLanguageException;

import java.util.EnumSet;

public enum Language {
  ET, EN, RU;

  public static Language fromString(String language) {
    return EnumSet.allOf(Language.class).stream()
        .filter(lang -> lang.name().equalsIgnoreCase(language))
        .findFirst()
        .orElseThrow(UnsupportedLanguageException::new);
  }
}
