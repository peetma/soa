package ee.ria.events.statuspanel.core.model;

public enum NotificationLevel {
  LOW_PRIORITY, INFO, WARNING, ERROR, SUCCESS
}
