package ee.ria.events.statuspanel.persistence;

import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceName;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.persistence.mapper.ServiceNameDboMapper;
import ee.ria.events.statuspanel.persistence.mapper.ServiceSetupVersionLocalizationDboMapper;
import ee.ria.events.statuspanel.persistence.repository.ServiceSetupVersionLocalizationDboRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class ServiceSetupVersionLocalizationPersistenceAdapter implements ServiceSetupVersionLocalizationPersistencePort {

  private final ServiceSetupVersionLocalizationDboRepository repository;
  private final ServiceSetupVersionLocalizationDboMapper mapper;
  private final ServiceNameDboMapper nameMapper;

  @Override
  public Mono<ServiceSetupVersionLocalization> getByVersionIdAndLanguage(
      Integer serviceSetupVersionId, Language language
  ) {
    return repository.findByServiceSetupVersionIdAndLanguageIgnoreCase(serviceSetupVersionId, language.name())
        .map(mapper::toModel);
  }

  @Override
  public Flux<ServiceSetupVersionLocalization> getByVersionId(Integer serviceSetupVersionId) {
    return repository.findByServiceSetupVersionId(serviceSetupVersionId)
        .map(mapper::toModel);
  }

  @Override
  public Flux<ServiceName> getServiceNamesByVersionIdsAndLanguage(List<Integer> serviceSetupVersionIds, Language language) {
    if (CollectionUtils.isEmpty(serviceSetupVersionIds)) {
      return Flux.empty();
    }

    return repository.findNameByServiceSetupVersionIdsAndLanguage(serviceSetupVersionIds, language.name())
        .map(nameMapper::toModel);
  }

  @Override
  public Flux<ServiceSetupVersionLocalization> save(List<ServiceSetupVersionLocalization> localizations) {
    return repository.saveAll(localizations.stream().map(mapper::toDbo).toList())
        .map(mapper::toModel);
  }

}
