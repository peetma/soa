package ee.ria.events.statuspanel.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Action {
  private String infoBoxTitle;
  private String infoBoxDescription;
  private String buttonText;
  private String url;
  private String returnUrl;
  private String returnUrlCode;
  private String imageName;
}
