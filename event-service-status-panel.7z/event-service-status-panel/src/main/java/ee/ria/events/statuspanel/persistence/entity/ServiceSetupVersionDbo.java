package ee.ria.events.statuspanel.persistence.entity;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDate;

@Data
@Table("service_setup_version")
@EqualsAndHashCode(callSuper = true)
public class ServiceSetupVersionDbo extends Auditable {

  @Id
  private Integer id;
  private Integer serviceSetupId;
  private LocalDate startDate;
  private Json owner;
  private boolean deleted;

}
