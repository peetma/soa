package ee.ria.events.statuspanel.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Owner {
  private String registerCode;
  private String name;
  private String contactPersonName;
  private String email;
  private String phoneNumber;
}
