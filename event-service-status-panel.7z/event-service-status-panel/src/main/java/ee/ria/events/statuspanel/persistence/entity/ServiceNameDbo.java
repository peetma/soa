package ee.ria.events.statuspanel.persistence.entity;

import lombok.Data;

@Data
public class ServiceNameDbo {
  private Integer serviceSetupVersionId;
  private String name;
}
