package ee.ria.events.statuspanel.rest.v1.mapper;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersionListItem;
import ee.ria.events.statuspanel.rest.v1.dto.ServiceSetupVersionListItemDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ServiceSetupVersionListItemDtoMapper
    extends BaseDtoMapper<ServiceSetupVersionListItemDto, ServiceSetupVersionListItem> {
}
