package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.model.*;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionLocalizationPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class GetServiceSetupVersionList {

  private final Clock clock;
  private final ServiceSetupVersionPersistencePort versionPort;
  private final ServiceSetupVersionLocalizationPersistencePort localizationPort;

  public Flux<ServiceSetupVersionListItem> execute() {
    Mono<List<ServiceSetupVersion>> versions = versionPort.getAllNonDeleted().collectList();

    return Mono.zip(
            versions,
            getServiceNames(versions),
            (versionList, serviceNamesByVersionId) -> versionList.stream()
                .map(version -> buildListItem(version, serviceNamesByVersionId.get(version.getId())))
                .toList())
        .flatMapMany(Flux::fromIterable)
        .sort(Comparator.comparing(ServiceSetupVersionListItem::getModified).reversed());
  }

  private Mono<Map<Integer, ServiceName>> getServiceNames(Mono<List<ServiceSetupVersion>> versions) {
    return versions.flatMapMany(versionList ->
        localizationPort.getServiceNamesByVersionIdsAndLanguage(
            versionList.stream().map(ServiceSetupVersion::getId).toList(), Language.ET
        )).collectMap(ServiceName::getServiceSetupVersionId);
  }

  private ServiceSetupVersionListItem buildListItem(ServiceSetupVersion version, ServiceName name) {
    ServiceSetupVersionStatus status =
        ServiceSetupVersionStatus.fromStartDate(LocalDate.now(clock), version.getStartDate());

    return ServiceSetupVersionListItem.builder()
        .id(version.getId())
        .serviceName(name.getName())
        .ownerName(version.getOwner().getName())
        .contactPersonName(version.getOwner().getContactPersonName())
        .contactPersonEmail(version.getOwner().getEmail())
        .startDate(version.getStartDate())
        .status(status)
        .modified(version.getModified())
        .editable(status.editable())
        .deletable(status.deletable())
        .build();
  }

}
