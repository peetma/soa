package ee.ria.events.statuspanel.persistence.mapper;

import io.r2dbc.postgresql.codec.Json;
import org.mapstruct.Named;

import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.springframework.util.CollectionUtils.isEmpty;

public interface BaseDboMapper<E, M> {

  M toModel(E entity);

  E toDbo(M model);

  @Named("objectToJson")
  default Json objectToJson(Object object) {
    return object == null ? null : JsonMapper.toJson(object);
  }

  @Named("listToJson")
  default Json listToJson(List<?> list) {
    return JsonMapper.toJson(isEmpty(list) ? emptyList() : list);
  }

  @Named("mapToJson")
  default Json mapToJson(Map<?, ?> map) {
    return JsonMapper.toJson(isEmpty(map) ? emptyMap() : map);
  }

}
