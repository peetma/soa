package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupVersionNotDeletableException;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class DeleteServiceSetupVersion {

  private final ServiceSetupVersionPersistencePort versionPort;

  @Transactional
  public Mono<Void> execute(Integer serviceSetupVersionId) {
    return versionPort.getById(serviceSetupVersionId)
        .switchIfEmpty(Mono.error(ServiceSetupNotFoundException::new))
        .filter(DeleteServiceSetupVersion::deletable)
        .switchIfEmpty(Mono.error(ServiceSetupVersionNotDeletableException::new))
        .filter(version -> !version.isDeleted())
        .map(version -> version.toBuilder().deleted(true).build())
        .flatMap(versionPort::save)
        .then();
  }

  private static boolean deletable(ServiceSetupVersion version) {
    return version.getStartDate() == null;
  }

}
