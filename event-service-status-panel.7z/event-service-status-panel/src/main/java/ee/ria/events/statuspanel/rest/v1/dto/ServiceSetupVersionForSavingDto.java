package ee.ria.events.statuspanel.rest.v1.dto;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class ServiceSetupVersionForSavingDto {
  OwnerDto owner;
  List<ServiceSetupVersionLocalizationDto> localizations;
}
