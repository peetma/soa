package ee.ria.events.statuspanel.persistence.mapper;

import ee.ria.events.statuspanel.core.model.Owner;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.persistence.entity.ServiceSetupVersionDbo;
import io.r2dbc.postgresql.codec.Json;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface ServiceSetupVersionDboMapper extends BaseDboMapper<ServiceSetupVersionDbo, ServiceSetupVersion> {

  @Override
  @Mapping(source = "owner", target = "owner", qualifiedByName = "jsonToOwner")
  ServiceSetupVersion toModel(ServiceSetupVersionDbo entity);

  @Override
  @Mapping(source = "owner", target = "owner", qualifiedByName = "objectToJson")
  ServiceSetupVersionDbo toDbo(ServiceSetupVersion model);

  @Named("jsonToOwner")
  default Owner jsonToOwner(Json owner) {
    return JsonMapper.getObject(owner, Owner.class);
  }

}
