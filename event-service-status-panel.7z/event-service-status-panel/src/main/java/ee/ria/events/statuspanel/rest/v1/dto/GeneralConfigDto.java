package ee.ria.events.statuspanel.rest.v1.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class GeneralConfigDto {
  String name;
  String description;
  String mobileHelpText;
  String keywords;
}
