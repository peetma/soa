package ee.ria.events.statuspanel.core.exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ServiceSetupLocalizationNotFoundException extends RuntimeException {

  public ServiceSetupLocalizationNotFoundException(Integer versionId, Integer localizationId) {
    super();
    log.error("Service setup localization {} not found for version {}", localizationId, versionId);
  }

}
