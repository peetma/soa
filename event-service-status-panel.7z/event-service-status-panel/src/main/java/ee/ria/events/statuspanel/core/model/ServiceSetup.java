package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.util.Map;

@Value
@Builder
public class ServiceSetup {
  Integer id;
  String serviceCode;
  Map<String, String> relativeUrls;
}
