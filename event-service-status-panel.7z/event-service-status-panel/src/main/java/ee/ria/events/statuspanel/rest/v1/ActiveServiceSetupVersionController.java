package ee.ria.events.statuspanel.rest.v1;

import ee.ria.events.statuspanel.core.usecase.GetActiveServiceSetupVersion;
import ee.ria.events.statuspanel.rest.v1.dto.EntireServiceSetupVersionDto;
import ee.ria.events.statuspanel.rest.v1.mapper.EntireServiceSetupVersionDtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

@RestController
@RequiredArgsConstructor
@RequestMapping("/internal/v1/services/setup/{serviceCode}/versions")
public class ActiveServiceSetupVersionController {

  private final GetActiveServiceSetupVersion getActiveServiceSetupVersion;
  private final EntireServiceSetupVersionDtoMapper versionMapper;

  @GetMapping
  @Operation(
      summary = "Get entire service setup version given setup",
      description = "Get version active on given date for specified event service"
  )
  @ApiResponse(responseCode = "200", description = "Success")
  @ApiResponse(responseCode = "404", description = "Setup or no active versions exist",
      content = @Content(schema = @Schema()))
  public Mono<EntireServiceSetupVersionDto> get(
      @PathVariable String serviceCode,
      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate activeOn
  ) {
    return getActiveServiceSetupVersion.execute(serviceCode, activeOn).map(versionMapper::toDto);
  }

}
