package ee.ria.events.statuspanel.persistence;

import ee.ria.events.statuspanel.core.model.ServiceSetupVersion;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import ee.ria.events.statuspanel.persistence.mapper.ServiceSetupVersionDboMapper;
import ee.ria.events.statuspanel.persistence.repository.ServiceSetupVersionDboRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.LocalDate;

@Repository
@RequiredArgsConstructor
public class ServiceSetupVersionPersistenceAdapter implements ServiceSetupVersionPersistencePort {

  private final ServiceSetupVersionDboRepository repository;
  private final ServiceSetupVersionDboMapper mapper;
  private final Clock clock;

  @Override
  public Mono<ServiceSetupVersion> getById(Integer id) {
    return repository.findById(id).map(mapper::toModel);
  }

  @Override
  public Mono<ServiceSetupVersion> getActiveOn(Integer serviceSetupId, LocalDate date) {
    return repository.findActiveOn(serviceSetupId, date).map(mapper::toModel);
  }

  @Override
  public Flux<ServiceSetupVersion> getAllActive() {
    return repository.findAllActive(LocalDate.now(clock))
        .map(mapper::toModel);
  }

  @Override
  public Flux<ServiceSetupVersion> getAllNonDeleted() {
    return repository.findByDeletedFalse().map(mapper::toModel);
  }

  @Override
  public Mono<ServiceSetupVersion> save(ServiceSetupVersion version) {
    return repository.save(mapper.toDbo(version))
        .map(mapper::toModel);
  }

}
