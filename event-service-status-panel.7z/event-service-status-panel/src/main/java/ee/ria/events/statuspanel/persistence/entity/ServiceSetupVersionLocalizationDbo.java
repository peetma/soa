package ee.ria.events.statuspanel.persistence.entity;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("service_setup_version_localization")
@EqualsAndHashCode(callSuper = true)
public class ServiceSetupVersionLocalizationDbo extends Auditable {

  @Id
  private Integer id;
  private Integer serviceSetupVersionId;
  private String language;
  private Json general;
  private Json steps;

}
