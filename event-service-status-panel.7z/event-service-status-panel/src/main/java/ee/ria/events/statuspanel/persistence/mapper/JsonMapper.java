package ee.ria.events.statuspanel.persistence.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.postgresql.codec.Json;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class JsonMapper {

  private static final ObjectMapper MAPPER = new ObjectMapper();

  public static <T> T getObject(Json json, Class<T> type) {
    try {
      return MAPPER.readValue(json.asString(), type);
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
  }

  public static Json toJson(Object object) {
    try {
      return Json.of(MAPPER.writeValueAsString(object));
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
  }
}
