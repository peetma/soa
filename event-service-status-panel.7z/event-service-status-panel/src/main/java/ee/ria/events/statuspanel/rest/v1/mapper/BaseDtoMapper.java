package ee.ria.events.statuspanel.rest.v1.mapper;

public interface BaseDtoMapper<E, M> {

  E toDto(M model);

  M toModel(E dto);

}
