package ee.ria.events.statuspanel.config;

import ee.ria.events.statuspanel.core.exception.ServiceSetupLocalizationNotFoundException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupNotFoundException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupVersionNotDeletableException;
import ee.ria.events.statuspanel.core.exception.ServiceSetupVersionNotEditableException;
import ee.ria.events.statuspanel.core.exception.UnsupportedLanguageException;
import ee.ria.events.statuspanel.core.exception.ValidationFailedException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.List;

import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.ResponseEntity.badRequest;
import static org.springframework.http.ResponseEntity.notFound;
import static org.springframework.http.ResponseEntity.status;

@ControllerAdvice
public class RestExceptionHandler {

  @ExceptionHandler(ValidationFailedException.class)
  ResponseEntity<List<ObjectError>> handleValidationFailed(ValidationFailedException ex) {
    return badRequest().body(ex.getErrors().getAllErrors());
  }

  @ExceptionHandler({
      ServiceSetupNotFoundException.class,
      UnsupportedLanguageException.class,
      ServiceSetupLocalizationNotFoundException.class
  })
  ResponseEntity<Void> handleNotFound() {
    return notFound().build();
  }

  @ExceptionHandler({
      ServiceSetupVersionNotEditableException.class,
      ServiceSetupVersionNotDeletableException.class
  })
  ResponseEntity<Void> handleForbidden() {
    return status(FORBIDDEN).build();
  }

}
