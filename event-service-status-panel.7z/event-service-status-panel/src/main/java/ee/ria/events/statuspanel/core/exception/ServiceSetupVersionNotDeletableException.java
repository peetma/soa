package ee.ria.events.statuspanel.core.exception;

public class ServiceSetupVersionNotDeletableException extends RuntimeException {
}
