package ee.ria.events.statuspanel.core.model;

import java.time.LocalDate;
import java.util.EnumSet;

public enum ServiceSetupVersionStatus {
  DRAFT, PENDING_PUBLICATION, PUBLISHED;

  public static ServiceSetupVersionStatus fromStartDate(LocalDate currentDate, LocalDate startDate) {
    if (startDate == null) {
      return DRAFT;
    }
    if (startDate.isAfter(currentDate)) {
      return PENDING_PUBLICATION;
    }
    return PUBLISHED;
  }

  public boolean editable() {
    return EnumSet.of(DRAFT, PENDING_PUBLICATION).contains(this);
  }

  public boolean deletable() {
    return this == DRAFT;
  }
}
