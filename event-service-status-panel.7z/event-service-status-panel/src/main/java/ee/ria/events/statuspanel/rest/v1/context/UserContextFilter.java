package ee.ria.events.statuspanel.rest.v1.context;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class UserContextFilter implements WebFilter {

  public static final String PERSONAL_CODE_HEADER = "user-personal-code";

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    return chain.filter(exchange)
        .contextWrite(UserContextHolder.withUserContext(Mono.just(createUserContext(exchange))));
  }

  private static UserContext createUserContext(ServerWebExchange exchange) {
    return new UserContext(getPersonalCode(exchange));
  }

  private static String getPersonalCode(ServerWebExchange exchange) {
    return exchange.getRequest().getHeaders().getFirst(PERSONAL_CODE_HEADER);
  }
}
