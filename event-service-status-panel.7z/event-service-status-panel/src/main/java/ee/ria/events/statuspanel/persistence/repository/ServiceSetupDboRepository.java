package ee.ria.events.statuspanel.persistence.repository;

import ee.ria.events.statuspanel.persistence.entity.ServiceSetupDbo;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface ServiceSetupDboRepository extends ReactiveCrudRepository<ServiceSetupDbo, Integer> {

  Mono<ServiceSetupDbo> findByServiceCode(String serviceCode);

}
