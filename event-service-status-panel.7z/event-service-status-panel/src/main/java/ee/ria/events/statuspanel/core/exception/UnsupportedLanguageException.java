package ee.ria.events.statuspanel.core.exception;

public class UnsupportedLanguageException extends RuntimeException {
}
