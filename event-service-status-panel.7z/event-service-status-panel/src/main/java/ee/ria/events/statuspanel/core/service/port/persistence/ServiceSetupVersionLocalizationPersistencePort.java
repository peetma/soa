package ee.ria.events.statuspanel.core.service.port.persistence;

import ee.ria.events.statuspanel.core.model.Language;
import ee.ria.events.statuspanel.core.model.ServiceName;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionLocalization;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ServiceSetupVersionLocalizationPersistencePort {

  Mono<ServiceSetupVersionLocalization> getByVersionIdAndLanguage(
      Integer serviceSetupVersionId, Language language
  );

  Flux<ServiceSetupVersionLocalization> getByVersionId(Integer serviceSetupVersionId);

  Flux<ServiceName> getServiceNamesByVersionIdsAndLanguage(List<Integer> serviceSetupVersionIds, Language language);

  Flux<ServiceSetupVersionLocalization> save(List<ServiceSetupVersionLocalization> localizations);

}
