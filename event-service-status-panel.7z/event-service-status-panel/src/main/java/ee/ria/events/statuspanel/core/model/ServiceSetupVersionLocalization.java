package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.time.Instant;
import java.util.List;

@Value
@Builder(toBuilder = true)
public class ServiceSetupVersionLocalization {
  Integer id;
  Integer serviceSetupVersionId;
  Language language;
  GeneralConfig general;
  List<StepConfig> steps;
  Instant created;
  String createdBy;
}
