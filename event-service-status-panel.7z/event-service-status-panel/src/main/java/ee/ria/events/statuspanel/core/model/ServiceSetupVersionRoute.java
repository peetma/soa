package ee.ria.events.statuspanel.core.model;

import lombok.Builder;
import lombok.Value;

import java.util.Map;

@Value
@Builder
public class ServiceSetupVersionRoute {
  Integer serviceSetupId;
  Integer serviceSetupVersionId;
  Map<String, String> relativeUrls;
}
