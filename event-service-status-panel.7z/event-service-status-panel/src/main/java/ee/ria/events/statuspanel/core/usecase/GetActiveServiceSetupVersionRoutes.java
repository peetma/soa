package ee.ria.events.statuspanel.core.usecase;

import ee.ria.events.statuspanel.core.model.ServiceSetup;
import ee.ria.events.statuspanel.core.model.ServiceSetupVersionRoute;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupPersistencePort;
import ee.ria.events.statuspanel.core.service.port.persistence.ServiceSetupVersionPersistencePort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Function;

@Component
@RequiredArgsConstructor
public class GetActiveServiceSetupVersionRoutes {

  private final ServiceSetupPersistencePort setupPort;
  private final ServiceSetupVersionPersistencePort versionPort;

  public Flux<ServiceSetupVersionRoute> execute() {
    return Mono.zip(
            versionPort.getAllActive().collectList(),
            setupPort.getAll().collectMap(ServiceSetup::getId, Function.identity()),
            (activeVersions, setupsById) -> activeVersions.stream()
                .map(version -> ServiceSetupVersionRoute.builder()
                    .serviceSetupId(version.getServiceSetupId())
                    .serviceSetupVersionId(version.getId())
                    .relativeUrls(setupsById.get(version.getServiceSetupId()).getRelativeUrls())
                    .build())
                .toList())
        .flatMapIterable(routes -> routes);
  }

}
