# Event Service Status Panel
[![Quality Gate Status](https://sonarqube.riaint.ee/api/project_badges/measure?project=SUN.event-service-status-panel&metric=alert_status&token=ceb8b9ba554f5894e7f093bd45a18247bedf1da1)](https://sonarqube.riaint.ee/dashboard?id=SUN.event-service-status-panel)

## Features
* Spring Boot 2.7.1
* Java 17
* PostgresSQL implementation of R2DBC
* Liquibase
* Lombok
* Swagger
* PgAdmin

## How to run:
* Use docker-compose up to run database and docker-compose down to stop it.
* To connect to the database via pgAdmin, use <b>host.docker.internal</b> as Host name/address instead of <b>localhost</b>
* Run via gradle command or set local profile to <b>local</b> and run directly from intellij;

### URLs
Swagger: http://localhost:8100/event-service-status-panel/swagger-ui.html
PgAdmin: http://localhost:5050

## Liquibase
* Use gradle liquibase plugin tasks

## Sonarqube
Running sonarqube locally: https://docs.sonarqube.org/latest/setup/get-started-2-minutes/
